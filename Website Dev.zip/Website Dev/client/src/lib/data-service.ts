// Shared data service for consistent statistics across the application

export const initialMockUsers = [
  { id: '1', name: 'John Doe', email: 'john@saggisolutions.com', role: 'admin', status: 'active' as const },
  { id: '2', name: 'Jane Smith', email: 'jane@saggisolutions.com', role: 'sales_manager', status: 'active' as const },
  { id: '3', name: 'Bob Johnson', email: 'bob@saggisolutions.com', role: 'sales_employee', status: 'active' as const },
  { id: '4', name: 'Alice Williams', email: 'alice@saggisolutions.com', role: 'candidate', status: 'active' as const },
  { id: '5', name: 'David Chen', email: 'david@saggisolutions.com', role: 'developer', status: 'active' as const },
  { id: '6', name: 'Emma Watson', email: 'emma@saggisolutions.com', role: 'candidate', status: 'active' as const },
  { id: '7', name: 'Michael Scott', email: 'michael@saggisolutions.com', role: 'sales_employee', status: 'inactive' as const },
];

export const initialMockBatches = [
  { 
    id: '1', 
    name: 'Net', 
    description: 'Microsoft .NET Technologies',
    startDate: '2024-01-15',
    durationMonths: 6,
    totalCandidates: 28,
    trainingCount: 12,
    mockInterviewCount: 8,
    marketingCount: 6,
    placedCount: 2,
    isActive: true
  },
  { 
    id: '2', 
    name: 'Dynamics', 
    description: 'Microsoft Dynamics 365',
    startDate: '2024-02-01',
    durationMonths: 4,
    totalCandidates: 17,
    trainingCount: 5,
    mockInterviewCount: 7,
    marketingCount: 3,
    placedCount: 2,
    isActive: true
  },
];

export function getAllUsers() {
  const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
  const modifiedInitialUsers = JSON.parse(localStorage.getItem('modifiedInitialUsers') || '[]');
  
  // Filter out initial users that have been modified
  const unmodifiedInitialUsers = initialMockUsers.filter(u => !modifiedInitialUsers.includes(u.id));
  
  // Merge unmodified initial users with stored users
  return [...unmodifiedInitialUsers, ...storedUsers];
}

export function getUsersByRole(role: string) {
  return getAllUsers().filter(u => u.role === role && u.status === 'active');
}

export function getStatistics() {
  const allUsers = getAllUsers();
  
  const totalUsers = allUsers.length;
  const activeCandidates = allUsers.filter(u => u.role === 'candidate' && u.status === 'active').length;
  const salesManagers = allUsers.filter(u => u.role === 'sales_manager' && u.status === 'active').length;
  const salesEmployees = allUsers.filter(u => u.role === 'sales_employee' && u.status === 'active').length;
  const salesTeam = salesManagers + salesEmployees;
  const developers = allUsers.filter(u => u.role === 'developer' && u.status === 'active').length;
  const admins = allUsers.filter(u => u.role === 'admin' && u.status === 'active').length;
  
  return {
    totalUsers,
    activeCandidates,
    salesManagers,
    salesEmployees,
    salesTeam,
    developers,
    admins,
  };
}

// Batch management functions
export function getAllBatches() {
  const storedBatches = JSON.parse(localStorage.getItem('batches') || '[]');
  const modifiedInitialBatches = JSON.parse(localStorage.getItem('modifiedInitialBatches') || '[]');
  const deletedInitialBatches = JSON.parse(localStorage.getItem('deletedInitialBatches') || '[]');
  
  // Filter out initial batches that have been modified or deleted
  const unmodifiedInitialBatches = initialMockBatches.filter(
    b => !modifiedInitialBatches.includes(b.id) && !deletedInitialBatches.includes(b.id)
  );
  
  // Merge unmodified initial batches with stored batches
  return [...unmodifiedInitialBatches, ...storedBatches];
}

export function getBatchById(id: string) {
  return getAllBatches().find(b => b.id === id);
}

export function getBatchStatistics() {
  const batches = getAllBatches();
  
  const totalBatches = batches.length;
  const activeBatches = batches.filter(b => b.isActive).length;
  const totalCandidates = batches.reduce((sum, b) => sum + b.totalCandidates, 0);
  const totalInTraining = batches.reduce((sum, b) => sum + b.trainingCount, 0);
  const totalPlaced = batches.reduce((sum, b) => sum + b.placedCount, 0);
  
  return {
    totalBatches,
    activeBatches,
    totalCandidates,
    totalInTraining,
    totalPlaced,
  };
}

// Candidate management functions
export interface CandidateBatchAssignment {
  userId: string;
  batchId: string;
  phase: 'training' | 'mock_interviews' | 'marketing' | 'placed';
  technology: string;
  experience: number;
}

export function getProgressFromPhase(phase: 'training' | 'mock_interviews' | 'marketing' | 'placed'): number {
  const phaseProgress = {
    training: 25,
    mock_interviews: 50,
    marketing: 75,
    placed: 100,
  };
  return phaseProgress[phase];
}

export function getCandidateUsers() {
  return getAllUsers().filter(u => u.role === 'candidate' && u.status === 'active');
}

export function getBatchAssignments() {
  return JSON.parse(localStorage.getItem('batchAssignments') || '[]') as CandidateBatchAssignment[];
}

export function getCandidatesByBatch(batchId: string) {
  const assignments = getBatchAssignments().filter(a => a.batchId === batchId);
  const candidateUsers = getCandidateUsers();
  
  return assignments
    .map(assignment => {
      const user = candidateUsers.find(u => u.id === assignment.userId);
      return user ? {
        id: user.id,
        name: user.name,
        email: user.email,
        technology: assignment.technology,
        batchId: assignment.batchId,
        phase: assignment.phase,
        experience: assignment.experience,
        progress: getProgressFromPhase(assignment.phase),
        status: user.status,
      } : null;
    })
    .filter((c): c is NonNullable<typeof c> => c !== null);
}

export function getCandidateAssignment(userId: string) {
  const assignments = getBatchAssignments();
  return assignments.find(a => a.userId === userId);
}

export function getUnassignedCandidates() {
  const candidateUsers = getCandidateUsers();
  const assignments = getBatchAssignments();
  const assignedUserIds = assignments.map(a => a.userId);
  
  return candidateUsers.filter(u => !assignedUserIds.includes(u.id));
}

export function assignCandidateToBatch(
  userId: string,
  batchId: string,
  technology: string,
  phase: 'training' | 'mock_interviews' | 'marketing' | 'placed',
  experience: number = 0
) {
  console.log('assignCandidateToBatch called with:', { userId, batchId, technology, phase, experience });
  
  const assignments = getBatchAssignments();
  console.log('Current assignments:', assignments);
  
  // Check if already assigned
  const existingIndex = assignments.findIndex(a => a.userId === userId);
  console.log('Existing index:', existingIndex);
  
  const newAssignment: CandidateBatchAssignment = {
    userId,
    batchId,
    technology,
    phase,
    experience,
  };
  console.log('New assignment:', newAssignment);
  
  if (existingIndex >= 0) {
    assignments[existingIndex] = newAssignment;
    console.log('Updated existing assignment');
  } else {
    assignments.push(newAssignment);
    console.log('Added new assignment');
  }
  
  console.log('Saving to localStorage:', assignments);
  localStorage.setItem('batchAssignments', JSON.stringify(assignments));
  console.log('Saved. Now updating batch counts...');
  updateBatchCandidateCounts(batchId);
  console.log('Batch counts updated');
}

export function removeCandidateFromBatch(userId: string) {
  const assignments = getBatchAssignments();
  const assignment = assignments.find(a => a.userId === userId);
  
  if (assignment) {
    const updatedAssignments = assignments.filter(a => a.userId !== userId);
    localStorage.setItem('batchAssignments', JSON.stringify(updatedAssignments));
    updateBatchCandidateCounts(assignment.batchId);
  }
}

export function updateBatchCandidateCounts(batchId: string) {
  const candidates = getCandidatesByBatch(batchId);
  
  const totalCandidates = candidates.length;
  const trainingCount = candidates.filter(c => c.phase === 'training').length;
  const mockInterviewCount = candidates.filter(c => c.phase === 'mock_interviews').length;
  const marketingCount = candidates.filter(c => c.phase === 'marketing').length;
  const placedCount = candidates.filter(c => c.phase === 'placed').length;
  
  // Update the batch with new counts
  const batch = getBatchById(batchId);
  if (batch) {
    const storedBatches = JSON.parse(localStorage.getItem('batches') || '[]');
    const modifiedInitialBatches = JSON.parse(localStorage.getItem('modifiedInitialBatches') || '[]');
    
    const updatedBatch = {
      ...batch,
      totalCandidates,
      trainingCount,
      mockInterviewCount,
      marketingCount,
      placedCount,
    };
    
    const batchIndex = storedBatches.findIndex((b: any) => b.id === batchId);
    const isInitialBatch = initialMockBatches.some(b => b.id === batchId);
    
    if (batchIndex >= 0) {
      storedBatches[batchIndex] = updatedBatch;
      localStorage.setItem('batches', JSON.stringify(storedBatches));
    } else if (isInitialBatch) {
      storedBatches.push(updatedBatch);
      localStorage.setItem('batches', JSON.stringify(storedBatches));
      
      if (!modifiedInitialBatches.includes(batchId)) {
        modifiedInitialBatches.push(batchId);
        localStorage.setItem('modifiedInitialBatches', JSON.stringify(modifiedInitialBatches));
      }
    }
  }
}

// Submission management functions
export interface Submission {
  id: string;
  candidateId: string;
  candidateName: string;
  company: string;
  submissionDate: string;
  rate: string;
  status: 'submitted' | 'initial_screening' | 'assessment' | 'interview' | 'offer' | 'placed' | 'rejected';
  notes?: string;
  comments?: string;
  createdBy: string;
  createdAt: string;
}

export function getAllSubmissions(): Submission[] {
  return JSON.parse(localStorage.getItem('submissions') || '[]');
}

export function getSubmissionById(id: string): Submission | undefined {
  return getAllSubmissions().find(s => s.id === id);
}

export function getSubmissionsByCandidate(candidateId: string): Submission[] {
  return getAllSubmissions().filter(s => s.candidateId === candidateId);
}

export function createSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Submission {
  const submissions = getAllSubmissions();
  const newSubmission: Submission = {
    ...submission,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
  };
  
  submissions.push(newSubmission);
  localStorage.setItem('submissions', JSON.stringify(submissions));
  
  return newSubmission;
}

export function updateSubmission(id: string, updates: Partial<Submission>): Submission | null {
  const submissions = getAllSubmissions();
  const index = submissions.findIndex(s => s.id === id);
  
  if (index === -1) return null;
  
  submissions[index] = { ...submissions[index], ...updates };
  localStorage.setItem('submissions', JSON.stringify(submissions));
  
  return submissions[index];
}

export function deleteSubmission(id: string): boolean {
  const submissions = getAllSubmissions();
  const filtered = submissions.filter(s => s.id !== id);
  
  if (filtered.length === submissions.length) return false;
  
  localStorage.setItem('submissions', JSON.stringify(filtered));
  return true;
}

export function getSubmissionsByCreator(creatorName: string): Submission[] {
  return getAllSubmissions().filter(s => s.createdBy === creatorName);
}

export function getSubmissionsForUser(userId: string): Submission[] {
  return getAllSubmissions().filter(s => s.candidateId === userId);
}

// Clean up orphaned candidate assignments (when candidates are deleted)
export function cleanupOrphanedAssignments() {
  const candidateUsers = getCandidateUsers();
  const candidateIds = candidateUsers.map(c => c.id);
  const assignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
  
  const cleanedAssignments: any = {};
  let hasChanges = false;
  
  Object.entries(assignments).forEach(([candidateId, assignment]) => {
    if (candidateIds.includes(candidateId)) {
      cleanedAssignments[candidateId] = assignment;
    } else {
      hasChanges = true;
      console.log('Removing orphaned assignment for deleted candidate:', candidateId);
    }
  });
  
  if (hasChanges) {
    localStorage.setItem('candidateAssignments', JSON.stringify(cleanedAssignments));
    console.log('Cleaned up orphaned assignments');
  }
  
  return hasChanges;
}


// Job Posting management functions
export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract';
  description: string;
  requirements: string;
  salary?: string;
  jobLink?: string;
  postedBy: string;
  postedDate: string;
  status: 'active' | 'closed';
}

export interface JobApplication {
  id: string;
  jobId: string;
  candidateId: string;
  candidateName: string;
  appliedBy: string; // Name of person who applied (candidate or sales person)
  appliedByRole: 'candidate' | 'sales_employee' | 'sales_manager';
  appliedDate: string;
  status: 'pending' | 'reviewed' | 'shortlisted' | 'rejected';
  notes?: string;
}

export function getAllJobs(): Job[] {
  return JSON.parse(localStorage.getItem('jobs') || '[]');
}

export function getJobById(id: string): Job | undefined {
  return getAllJobs().find(j => j.id === id);
}

export function createJob(job: Omit<Job, 'id' | 'postedDate'>): Job {
  const jobs = getAllJobs();
  const newJob: Job = {
    ...job,
    id: Date.now().toString(),
    postedDate: new Date().toISOString(),
  };
  
  jobs.push(newJob);
  localStorage.setItem('jobs', JSON.stringify(jobs));
  
  return newJob;
}

export function updateJob(id: string, updates: Partial<Job>): Job | null {
  const jobs = getAllJobs();
  const index = jobs.findIndex(j => j.id === id);
  
  if (index === -1) return null;
  
  jobs[index] = { ...jobs[index], ...updates };
  localStorage.setItem('jobs', JSON.stringify(jobs));
  
  return jobs[index];
}

export function deleteJob(id: string): boolean {
  const jobs = getAllJobs();
  const filtered = jobs.filter(j => j.id !== id);
  
  if (filtered.length === jobs.length) return false;
  
  localStorage.setItem('jobs', JSON.stringify(filtered));
  
  // Also delete related applications
  const applications = getAllJobApplications();
  const filteredApps = applications.filter(a => a.jobId !== id);
  localStorage.setItem('jobApplications', JSON.stringify(filteredApps));
  
  return true;
}

export function getAllJobApplications(): JobApplication[] {
  return JSON.parse(localStorage.getItem('jobApplications') || '[]');
}

export function getJobApplicationsByJob(jobId: string): JobApplication[] {
  return getAllJobApplications().filter(a => a.jobId === jobId);
}

export function getJobApplicationsByCandidate(candidateId: string): JobApplication[] {
  return getAllJobApplications().filter(a => a.candidateId === candidateId);
}

export function createJobApplication(application: Omit<JobApplication, 'id' | 'appliedDate'>): JobApplication {
  const applications = getAllJobApplications();
  
  // Check if already applied
  const existing = applications.find(a => a.jobId === application.jobId && a.candidateId === application.candidateId);
  if (existing) {
    throw new Error('Already applied to this job');
  }
  
  const newApplication: JobApplication = {
    ...application,
    id: Date.now().toString(),
    appliedDate: new Date().toISOString(),
  };
  
  applications.push(newApplication);
  localStorage.setItem('jobApplications', JSON.stringify(applications));
  
  return newApplication;
}

export function updateJobApplication(id: string, updates: Partial<JobApplication>): JobApplication | null {
  const applications = getAllJobApplications();
  const index = applications.findIndex(a => a.id === id);
  
  if (index === -1) return null;
  
  applications[index] = { ...applications[index], ...updates };
  localStorage.setItem('jobApplications', JSON.stringify(applications));
  
  return applications[index];
}

export function deleteJobApplication(id: string): boolean {
  const applications = getAllJobApplications();
  const filtered = applications.filter(a => a.id !== id);
  
  if (filtered.length === applications.length) return false;
  
  localStorage.setItem('jobApplications', JSON.stringify(filtered));
  return true;
}

// Get interviews (submissions with interview status)
export function getInterviews(): Submission[] {
  return getAllSubmissions().filter(s => s.status === 'interview');
}

export function getInterviewsByCreator(creatorName: string): Submission[] {
  return getInterviews().filter(s => s.createdBy === creatorName);
}
