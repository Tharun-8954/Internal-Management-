import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  FileText,
  UserCheck,
  Briefcase,
  Video,
  Target
} from 'lucide-react';

export const adminNavItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Submissions', url: '/admin/submissions', icon: FileText },
  { title: 'Interviews', url: '/admin/interviews', icon: Video },
  { title: 'Jobs', url: '/admin/jobs', icon: Briefcase },
  { title: 'Assignments', url: '/admin/assignments', icon: Target },
];
