// Seed initial data for development
import { 
  initialMockUsers, 
  initialMockBatches,
  type Submission,
  type Job,
  type JobApplication,
  type CandidateBatchAssignment
} from './data-service';

export function seedInitialData() {
  // Check if any data already exists - if so, don't seed
  const hasSubmissions = localStorage.getItem('submissions');
  const hasJobs = localStorage.getItem('jobs');
  const hasBatchAssignments = localStorage.getItem('batchAssignments');
  const hasJobApplications = localStorage.getItem('jobApplications');
  
  if (hasSubmissions || hasJobs || hasBatchAssignments || hasJobApplications) {
    console.log('Existing data found, preserving it...');
    return;
  }

  console.log('No existing data found. Seeding initial data...');

  // Seed batch assignments
  const batchAssignments: CandidateBatchAssignment[] = [
    { userId: '4', batchId: '1', phase: 'training', technology: '.NET Core', experience: 0 },
    { userId: '6', batchId: '2', phase: 'mock_interviews', technology: 'Dynamics 365', experience: 1 },
  ];
  localStorage.setItem('batchAssignments', JSON.stringify(batchAssignments));

  // Seed submissions
  const submissions: Submission[] = [
    {
      id: '1',
      candidateId: '4',
      candidateName: 'Alice Williams',
      company: 'Tech Corp',
      submissionDate: '2024-11-15',
      rate: '$75/hr',
      status: 'interview',
      notes: 'Strong technical background',
      createdBy: 'Bob Johnson',
      createdAt: '2024-11-15T10:00:00Z',
    },
    {
      id: '2',
      candidateId: '6',
      candidateName: 'Emma Watson',
      company: 'Innovation Labs',
      submissionDate: '2024-11-20',
      rate: '$80/hr',
      status: 'submitted',
      notes: 'Excellent communication skills',
      createdBy: 'Bob Johnson',
      createdAt: '2024-11-20T14:30:00Z',
    },
    {
      id: '3',
      candidateId: '4',
      candidateName: 'Alice Williams',
      company: 'Global Solutions',
      submissionDate: '2024-11-25',
      rate: '$70/hr',
      status: 'assessment',
      notes: 'Good fit for the role',
      createdBy: 'Bob Johnson',
      createdAt: '2024-11-25T09:15:00Z',
    },
  ];
  localStorage.setItem('submissions', JSON.stringify(submissions));

  // Seed jobs
  const jobs: Job[] = [
    {
      id: '1',
      title: 'Senior .NET Developer',
      company: 'Tech Corp',
      location: 'Remote',
      type: 'full-time',
      description: 'Looking for an experienced .NET developer to join our team.',
      requirements: '5+ years of .NET experience, C#, ASP.NET Core, SQL Server',
      salary: '$120k - $150k',
      jobLink: 'https://example.com/job1',
      postedBy: 'Jane Smith',
      postedDate: '2024-11-01T00:00:00Z',
      status: 'active',
    },
    {
      id: '2',
      title: 'Dynamics 365 Consultant',
      company: 'Innovation Labs',
      location: 'Hybrid',
      type: 'contract',
      description: 'Seeking a Dynamics 365 consultant for a 6-month project.',
      requirements: 'Dynamics 365 CE/CRM, Power Platform, 3+ years experience',
      salary: '$90/hr',
      jobLink: 'https://example.com/job2',
      postedBy: 'Jane Smith',
      postedDate: '2024-11-10T00:00:00Z',
      status: 'active',
    },
  ];
  localStorage.setItem('jobs', JSON.stringify(jobs));

  // Seed job applications
  const jobApplications: JobApplication[] = [
    {
      id: '1',
      jobId: '1',
      candidateId: '4',
      candidateName: 'Alice Williams',
      appliedBy: 'Bob Johnson',
      appliedByRole: 'sales_employee',
      appliedDate: '2024-11-15T10:00:00Z',
      status: 'shortlisted',
      notes: 'Strong candidate for this position',
    },
    {
      id: '2',
      jobId: '2',
      candidateId: '6',
      candidateName: 'Emma Watson',
      appliedBy: 'Bob Johnson',
      appliedByRole: 'sales_employee',
      appliedDate: '2024-11-20T14:30:00Z',
      status: 'pending',
    },
  ];
  localStorage.setItem('jobApplications', JSON.stringify(jobApplications));

  // Mark as seeded
  localStorage.setItem('dataSeeded', 'true');
  
  console.log('Initial data seeded successfully!');
}

// Function to reset all data (useful for development)
export function resetData() {
  localStorage.clear();
  console.log('All data cleared from localStorage');
}

// Function to check if data exists
export function hasData() {
  return localStorage.getItem('dataSeeded') === 'true';
}
