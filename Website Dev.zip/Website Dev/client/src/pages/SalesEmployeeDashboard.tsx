import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import StatCard from '@/components/StatCard';
import CandidateCard from '@/components/CandidateCard';
import SubmissionTable from '@/components/SubmissionTable';
import { Button } from '@/components/ui/button';
import { getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase, getAllSubmissions } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  CheckCircle,
  Send 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

// Get current user ID - in real app this would come from auth context
// For now, using Bob Johnson's ID from initial data
const CURRENT_USER_ID = '3'; // Bob Johnson

interface SalesEmployeeDashboardProps {
  onLogout?: () => void;
}

export default function SalesEmployeeDashboard({ onLogout }: SalesEmployeeDashboardProps) {
  const [, setLocation] = useLocation();
  const [candidates, setCandidates] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [stats, setStats] = useState({ assigned: 0, submissions: 0, placements: 0 });

  useEffect(() => {
    loadData();
    
    window.addEventListener('storage', loadData);
    window.addEventListener('focus', loadData);
    window.addEventListener('candidateAssignmentChanged', loadData);
    
    return () => {
      window.removeEventListener('storage', loadData);
      window.removeEventListener('focus', loadData);
      window.removeEventListener('candidateAssignmentChanged', loadData);
    };
  }, []);

  const loadData = () => {
    // Get assignments for this sales employee
    const assignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
    const myAssignments = Object.entries(assignments)
      .filter(([_, assignment]: [string, any]) => assignment.assignedToId === CURRENT_USER_ID)
      .map(([candidateId, _]) => candidateId);
    
    // Get candidate details
    const candidateUsers = getCandidateUsers();
    const batchAssignments = getBatchAssignments();
    const batches = getAllBatches();
    
    const myCandidates = myAssignments
      .map(candidateId => {
        const candidateUser = candidateUsers.find(c => c.id === candidateId);
        if (!candidateUser) return null;
        
        const batchAssignment = batchAssignments.find(a => a.userId === candidateId);
        if (!batchAssignment) return null;
        
        const batch = batches.find(b => b.id === batchAssignment.batchId);
        
        return {
          id: candidateUser.id,
          name: candidateUser.name,
          technology: batchAssignment.technology,
          batch: batch?.name || 'Unknown',
          phase: batchAssignment.phase,
          experience: batchAssignment.experience,
          progress: getProgressFromPhase(batchAssignment.phase),
        };
      })
      .filter(Boolean);
    
    setCandidates(myCandidates);
    
    // Get submissions created by this user
    const allSubmissions = getAllSubmissions();
    const mySubmissions = allSubmissions
      .filter(sub => sub.createdBy === 'Bob Johnson') // In real app, match by user ID
      .sort((a, b) => new Date(b.submissionDate).getTime() - new Date(a.submissionDate).getTime())
      .slice(0, 5); // Show recent 5
    
    setSubmissions(mySubmissions);
    
    // Calculate stats
    const placedCount = myCandidates.filter((c: any) => c.phase === 'placed').length;
    
    setStats({
      assigned: myCandidates.length,
      submissions: allSubmissions.filter(sub => sub.createdBy === 'Bob Johnson').length,
      placements: placedCount,
    });
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">🏠 My Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Manage your assigned candidates and submissions
            </p>
          </div>
          <Button onClick={() => setLocation('/sales/submissions/new')} data-testid="button-new-submission">
            <Send className="mr-2 h-4 w-4" />
            New Submission
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard
            title="Assigned Candidates"
            value={stats.assigned}
            icon={Users}
            description="Active assignments"
          />
          <StatCard
            title="Submissions"
            value={stats.submissions}
            icon={Send}
            description="Total submissions"
          />
          <StatCard
            title="Placements"
            value={stats.placements}
            icon={CheckCircle}
            description="Successfully placed"
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">My Candidates ({candidates.length})</h2>
          </div>
          {candidates.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No candidates assigned yet</p>
              <p className="text-sm mt-1">Your manager will assign candidates to you</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {candidates.map(candidate => (
                <CandidateCard
                  key={candidate.id}
                  {...candidate}
                  onClick={() => setLocation(`/sales/candidates/${candidate.id}`)}
                />
              ))}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Recent Submissions</h2>
          {submissions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No submissions yet</p>
            </div>
          ) : (
            <SubmissionTable
              submissions={submissions}
              onViewDetails={(id) => setLocation(`/sales/submissions/${id}`)}
            />
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
