import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  LayoutDashboard, 
  Code, 
  GitBranch, 
  FileText,
  Terminal,
  Folder,
  Plus
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/dev/dashboard', icon: LayoutDashboard },
  { title: 'Projects', url: '/dev/projects', icon: Folder },
  { title: 'Code Reviews', url: '/dev/reviews', icon: Code },
  { title: 'Documentation', url: '/dev/docs', icon: FileText },
  { title: 'Git Activity', url: '/dev/git', icon: GitBranch },
];

const mockProjects = [
  { id: 1, name: 'Internal CRM System', status: 'In Progress', progress: 75, lastCommit: '2 hours ago', language: 'C#', framework: '.NET Core' },
  { id: 2, name: 'API Gateway', status: 'Review', progress: 90, lastCommit: '1 day ago', language: 'C#', framework: '.NET Core' },
  { id: 3, name: 'Analytics Dashboard', status: 'Planning', progress: 25, lastCommit: '3 days ago', language: 'TypeScript', framework: 'React' },
  { id: 4, name: 'Authentication Service', status: 'Completed', progress: 100, lastCommit: '1 week ago', language: 'C#', framework: '.NET Core' },
];

interface ProjectsProps {
  onLogout?: () => void;
}

export default function Projects({ onLogout }: ProjectsProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="David Chen"
      userRole="Developer"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Projects</h1>
            <p className="text-muted-foreground mt-1">
              Manage and track all your development projects
            </p>
          </div>
          <Button onClick={() => setLocation('/dev/projects?action=new')} data-testid="button-new-project">
            <Plus className="mr-2 h-4 w-4" />
            New Project
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {mockProjects.map((project) => (
            <Card 
              key={project.id} 
              className="hover-elevate cursor-pointer"
              onClick={() => setLocation(`/dev/projects/${project.id}`)}
              data-testid={`card-project-${project.id}`}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary" className="text-xs">{project.language}</Badge>
                      <Badge variant="secondary" className="text-xs">{project.framework}</Badge>
                    </div>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={
                      project.status === 'Completed' 
                        ? 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20'
                        : project.status === 'In Progress'
                        ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20'
                        : project.status === 'Review'
                        ? 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20'
                        : 'bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20'
                    }
                  >
                    {project.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Last commit: {project.lastCommit}
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-2" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
