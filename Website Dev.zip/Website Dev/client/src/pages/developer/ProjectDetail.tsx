import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  LayoutDashboard, 
  Code, 
  GitBranch, 
  FileText,
  Terminal,
  Folder,
  ArrowLeft,
  GitCommit
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/dev/dashboard', icon: LayoutDashboard },
  { title: 'Projects', url: '/dev/projects', icon: Folder },
  { title: 'Code Reviews', url: '/dev/reviews', icon: Code },
  { title: 'Documentation', url: '/dev/docs', icon: FileText },
  { title: 'Git Activity', url: '/dev/git', icon: GitBranch },
];

const recentCommits = [
  { id: 1, message: 'feat: Add user authentication', author: 'David Chen', time: '2 hours ago', hash: 'a1b2c3d' },
  { id: 2, message: 'fix: Resolve API endpoint issue', author: 'David Chen', time: '5 hours ago', hash: 'e4f5g6h' },
  { id: 3, message: 'docs: Update README', author: 'David Chen', time: '1 day ago', hash: 'i7j8k9l' },
];

interface ProjectDetailProps {
  onLogout?: () => void;
}

export default function ProjectDetail({ onLogout }: ProjectDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="David Chen"
      userRole="Developer"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/dev/projects')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Internal CRM System</h1>
            <p className="text-muted-foreground mt-1">Project #{params.id}</p>
          </div>
          <Badge variant="outline" className="bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20">
            In Progress
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Commits</CardTitle>
              <GitCommit className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">147</div>
              <p className="text-xs text-muted-foreground mt-1">Last 30 days</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Branches</CardTitle>
              <GitBranch className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground mt-1">3 feature, 2 hotfix</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Build Status</CardTitle>
              <Terminal className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">Passing</div>
              <p className="text-xs text-muted-foreground mt-1">All tests passed</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Project Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Overall Completion</span>
                <span className="text-sm text-muted-foreground">75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
              <div className="text-center p-3 border rounded-md">
                <p className="text-xs text-muted-foreground mb-1">Planning</p>
                <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
                  Done
                </Badge>
              </div>
              <div className="text-center p-3 border rounded-md">
                <p className="text-xs text-muted-foreground mb-1">Development</p>
                <Badge variant="outline" className="bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20">
                  In Progress
                </Badge>
              </div>
              <div className="text-center p-3 border rounded-md">
                <p className="text-xs text-muted-foreground mb-1">Testing</p>
                <Badge variant="outline" className="bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20">
                  Pending
                </Badge>
              </div>
              <div className="text-center p-3 border rounded-md">
                <p className="text-xs text-muted-foreground mb-1">Deployment</p>
                <Badge variant="outline" className="bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20">
                  Pending
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Commits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentCommits.map((commit) => (
                <div key={commit.id} className="flex items-start gap-3 p-3 border rounded-md">
                  <GitCommit className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{commit.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="text-xs">{commit.hash}</Badge>
                      <span className="text-xs text-muted-foreground">{commit.author}</span>
                      <span className="text-xs text-muted-foreground">• {commit.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
