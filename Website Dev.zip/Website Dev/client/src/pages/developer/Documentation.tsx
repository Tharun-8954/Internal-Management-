import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutDashboard, 
  Code, 
  GitBranch, 
  FileText,
  Terminal,
  Folder,
  Search,
  Plus
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/dev/dashboard', icon: LayoutDashboard },
  { title: 'Projects', url: '/dev/projects', icon: Folder },
  { title: 'Code Reviews', url: '/dev/reviews', icon: Code },
  { title: 'Documentation', url: '/dev/docs', icon: FileText },
  { title: 'Git Activity', url: '/dev/git', icon: GitBranch },
];

const docs = [
  { id: 1, title: 'API Documentation', project: 'API Gateway', lastUpdated: '2 days ago', category: 'Technical' },
  { id: 2, title: 'Database Schema', project: 'Internal CRM', lastUpdated: '1 week ago', category: 'Technical' },
  { id: 3, title: 'Deployment Guide', project: 'All Projects', lastUpdated: '3 days ago', category: 'Operations' },
  { id: 4, title: 'Code Standards', project: 'All Projects', lastUpdated: '2 weeks ago', category: 'Guidelines' },
  { id: 5, title: 'Security Best Practices', project: 'All Projects', lastUpdated: '1 week ago', category: 'Security' },
];

interface DocumentationProps {
  onLogout?: () => void;
}

export default function Documentation({ onLogout }: DocumentationProps) {
  return (
    <DashboardLayout
      navItems={navItems}
      userName="David Chen"
      userRole="Developer"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Documentation</h1>
            <p className="text-muted-foreground mt-1">
              Project documentation and technical guides
            </p>
          </div>
          <Button data-testid="button-new-doc">
            <Plus className="mr-2 h-4 w-4" />
            New Document
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search documentation..."
              className="pl-10"
              data-testid="input-search-docs"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {docs.map((doc) => (
            <Card key={doc.id} className="hover-elevate cursor-pointer" data-testid={`card-doc-${doc.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-base">{doc.title}</CardTitle>
                    <p className="text-xs text-muted-foreground mt-1">{doc.project}</p>
                  </div>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <Badge variant="secondary" className="text-xs">
                  {doc.category}
                </Badge>
                <p className="text-xs text-muted-foreground">
                  Updated {doc.lastUpdated}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
