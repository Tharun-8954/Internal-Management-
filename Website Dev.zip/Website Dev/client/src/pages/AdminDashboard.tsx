import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import StatCard from '@/components/StatCard';
import BatchCard from '@/components/BatchCard';
import { Card, CardContent } from '@/components/ui/card';
import { getStatistics, getAllBatches } from '@/lib/data-service';
import { TrendingUp, Users, UserCheck, Briefcase, GraduationCap } from 'lucide-react';
import { adminNavItems } from '@/lib/admin-nav';

const navItems = adminNavItems;

interface AdminDashboardProps {
  onLogout?: () => void;
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [, setLocation] = useLocation();
  const [stats, setStats] = useState(getStatistics());
  const [batches, setBatches] = useState(getAllBatches());

  useEffect(() => {
    // Update stats when component mounts or when returning from other pages
    const updateData = () => {
      console.log('Updating dashboard statistics...');
      const newStats = getStatistics();
      console.log('New stats:', newStats);
      setStats(newStats);
      setBatches(getAllBatches());
    };
    updateData();
    
    // Listen for storage changes (when users are added/modified)
    window.addEventListener('storage', updateData);
    window.addEventListener('focus', updateData);
    
    // Also set up an interval to check for updates every 2 seconds
    const interval = setInterval(updateData, 2000);
    
    return () => {
      window.removeEventListener('storage', updateData);
      window.removeEventListener('focus', updateData);
      clearInterval(interval);
    };
  }, []);

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Manage users, batches, and monitor system performance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total Users"
            value={stats.totalUsers}
            icon={Users}
            description="All system users"
          />
          <StatCard
            title="Active Candidates"
            value={stats.activeCandidates}
            icon={UserCheck}
            description="Across both batches"
          />
          <StatCard
            title="Sales Team"
            value={stats.salesTeam}
            icon={Briefcase}
            description={`${stats.salesManagers} ${stats.salesManagers === 1 ? 'manager' : 'managers'}, ${stats.salesEmployees} ${stats.salesEmployees === 1 ? 'employee' : 'employees'}`}
          />
          <StatCard
            title="Total Batches"
            value={batches.length}
            icon={GraduationCap}
            description={`${batches.filter(b => b.isActive).length} active`}
          />
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4">Access Other Role Dashboards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation('/manager/dashboard')}>
              <CardContent className="p-6 text-center">
                <Users className="h-12 w-12 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold text-lg">Sales Manager</h3>
                <p className="text-sm text-muted-foreground mt-1">Team & Assignments</p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation('/sales/dashboard')}>
              <CardContent className="p-6 text-center">
                <Briefcase className="h-12 w-12 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold text-lg">Sales Employee</h3>
                <p className="text-sm text-muted-foreground mt-1">Candidates & Submissions</p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation('/candidate/dashboard')}>
              <CardContent className="p-6 text-center">
                <UserCheck className="h-12 w-12 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold text-lg">Candidate</h3>
                <p className="text-sm text-muted-foreground mt-1">Progress & Interviews</p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation('/dev/dashboard')}>
              <CardContent className="p-6 text-center">
                <TrendingUp className="h-12 w-12 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold text-lg">Developer</h3>
                <p className="text-sm text-muted-foreground mt-1">Projects & Code Reviews</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Batches</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {batches.map(batch => (
              <BatchCard
                key={batch.id}
                {...batch}
                onViewDetails={() => setLocation(`/admin/batches/${batch.id}`)}
              />
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
