import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  User, 
  Briefcase, 
  MessageSquare,
  BookOpen,
  Download,
  ExternalLink,
  FileText,
  Video,
  Code
} from 'lucide-react';

const navItems = [
  { title: 'My Profile', url: '/candidate/dashboard', icon: User },
  { title: 'My Progress', url: '/candidate/progress', icon: Briefcase },
  { title: 'Mock Interviews', url: '/candidate/interviews', icon: MessageSquare },
  { title: 'Resources', url: '/candidate/resources', icon: BookOpen },
];

const resources = {
  documents: [
    { id: 1, title: '.NET Core Development Guide', type: 'PDF', size: '2.3 MB' },
    { id: 2, title: 'C# Best Practices', type: 'PDF', size: '1.8 MB' },
    { id: 3, title: 'Interview Preparation Checklist', type: 'PDF', size: '450 KB' },
  ],
  videos: [
    { id: 1, title: 'ASP.NET Core Tutorial Series', duration: '4:30:00', category: 'Technical' },
    { id: 2, title: 'Effective Communication Skills', duration: '1:15:00', category: 'Soft Skills' },
    { id: 3, title: 'Mock Interview Examples', duration: '2:00:00', category: 'Interview Prep' },
  ],
  links: [
    { id: 1, title: 'Microsoft Learn - .NET', url: 'https://learn.microsoft.com/dotnet' },
    { id: 2, title: 'C# Documentation', url: 'https://docs.microsoft.com/csharp' },
    { id: 3, title: 'LeetCode Practice', url: 'https://leetcode.com' },
  ],
  code: [
    { id: 1, title: 'Sample Project Templates', language: 'C#' },
    { id: 2, title: 'Common Design Patterns', language: 'C#' },
    { id: 3, title: 'Interview Coding Challenges', language: 'C#' },
  ]
};

interface ResourcesProps {
  onLogout?: () => void;
}

export default function Resources({ onLogout }: ResourcesProps) {
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Alice Williams"
      userRole="Candidate"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Learning Resources</h1>
          <p className="text-muted-foreground mt-1">Access training materials and study guides</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Documents & Guides</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {resources.documents.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-3 border rounded-md hover-elevate" data-testid={`doc-${doc.id}`}>
                  <div className="flex items-center gap-3">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{doc.title}</p>
                      <p className="text-xs text-muted-foreground">{doc.type} • {doc.size}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Video Tutorials</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {resources.videos.map((video) => (
                <div key={video.id} className="flex items-center justify-between p-3 border rounded-md hover-elevate" data-testid={`video-${video.id}`}>
                  <div className="flex items-center gap-3">
                    <Video className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{video.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">{video.category}</Badge>
                        <span className="text-xs text-muted-foreground">{video.duration}</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    Watch
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Useful Links</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {resources.links.map((link) => (
                <div key={link.id} className="flex items-center justify-between p-3 border rounded-md hover-elevate" data-testid={`link-${link.id}`}>
                  <div className="flex items-center gap-3">
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm font-medium">{link.title}</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    Visit
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Code Samples</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {resources.code.map((code) => (
                <div key={code.id} className="flex items-center justify-between p-3 border rounded-md hover-elevate" data-testid={`code-${code.id}`}>
                  <div className="flex items-center gap-3">
                    <Code className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{code.title}</p>
                      <Badge variant="secondary" className="text-xs mt-1">{code.language}</Badge>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
