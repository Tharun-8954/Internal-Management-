import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import StatCard from '@/components/StatCard';
import CandidateCard from '@/components/CandidateCard';
import SubmissionTable from '@/components/SubmissionTable';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getStatistics, getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  TrendingUp 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

// No hardcoded data - will pull from data service

interface SalesManagerDashboardProps {
  onLogout?: () => void;
}

export default function SalesManagerDashboard({ onLogout }: SalesManagerDashboardProps) {
  console.log('🟢 SalesManagerDashboard component loaded - PIPELINE VIEW');
  
  const [, setLocation] = useLocation();
  const [stats, setStats] = useState(getStatistics());
  const [candidates, setCandidates] = useState<any[]>([]);
  const [submissions] = useState<any[]>([]); // Will be implemented with submission system

  useEffect(() => {
    const updateData = () => {
      setStats(getStatistics());
      
      // Get all candidates from batch assignments
      const candidateUsers = getCandidateUsers();
      const batchAssignments = getBatchAssignments();
      const batches = getAllBatches();
      
      const candidateList = candidateUsers.map(user => {
        const assignment = batchAssignments.find(a => a.userId === user.id);
        const batch = assignment ? batches.find(b => b.id === assignment.batchId) : null;
        
        return assignment ? {
          id: user.id,
          name: user.name,
          technology: assignment.technology,
          batch: batch?.name || 'Unknown',
          phase: assignment.phase,
          experience: assignment.experience,
          progress: getProgressFromPhase(assignment.phase),
        } : null;
      }).filter(Boolean);
      
      setCandidates(candidateList);
    };
    
    updateData();
    
    window.addEventListener('focus', updateData);
    window.addEventListener('storage', updateData);
    
    return () => {
      window.removeEventListener('focus', updateData);
      window.removeEventListener('storage', updateData);
    };
  }, []);

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Sales Manager Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Manage your team and track candidate progress
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Sales Employees"
            value={stats.salesEmployees}
            icon={Users}
            description="Active team members"
          />
          <StatCard
            title="Active Candidates"
            value={stats.activeCandidates}
            icon={Target}
            description="Ready for assignment"
          />
          <StatCard
            title="This Month Placed"
            value={candidates.filter((c: any) => c.phase === 'placed').length}
            icon={TrendingUp}
            description="Successfully placed"
          />
          <StatCard
            title="In Marketing"
            value={candidates.filter((c: any) => c.phase === 'marketing').length}
            icon={FileText}
            description="Ready for placement"
          />
        </div>

        <Tabs defaultValue="candidates" className="space-y-4">
          <TabsList>
            <TabsTrigger value="candidates" data-testid="tab-candidates">Candidates</TabsTrigger>
            <TabsTrigger value="submissions" data-testid="tab-submissions">Recent Submissions</TabsTrigger>
            <TabsTrigger value="team" data-testid="tab-team">Team Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="candidates" className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Candidate Pipeline</h2>
              <Button onClick={() => setLocation('/manager/assignments')} data-testid="button-assign-candidates">
                <Target className="mr-2 h-4 w-4" />
                Assign Candidates
              </Button>
            </div>
            {candidates.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">No candidates available</p>
                <p className="text-sm mt-1">Assign candidates to batches first</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {candidates.map((candidate: any) => (
                  <CandidateCard
                    key={candidate.id}
                    {...candidate}
                    batch={candidate.batch as any}
                    onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="submissions" className="space-y-4">
            {submissions.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <FileText className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">No submissions yet</p>
                <p className="text-sm mt-1">Submissions will appear here</p>
              </div>
            ) : (
              <SubmissionTable
                submissions={submissions}
                onViewDetails={(id) => setLocation(`/manager/submissions/${id}`)}
              />
            )}
          </TabsContent>

          <TabsContent value="team" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Candidates by Phase</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Training</span>
                    <span className="text-sm font-semibold">
                      {candidates.filter((c: any) => c.phase === 'training').length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Mock Interviews</span>
                    <span className="text-sm font-semibold">
                      {candidates.filter((c: any) => c.phase === 'mock_interviews').length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Marketing</span>
                    <span className="text-sm font-semibold">
                      {candidates.filter((c: any) => c.phase === 'marketing').length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Placed</span>
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                      {candidates.filter((c: any) => c.phase === 'placed').length}
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Team Overview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Sales Employees</span>
                    <span className="text-sm font-semibold">{stats.salesEmployees}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Candidates</span>
                    <span className="text-sm font-semibold">{candidates.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Unassigned</span>
                    <span className="text-sm font-semibold text-yellow-600 dark:text-yellow-400">
                      {candidates.length}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
