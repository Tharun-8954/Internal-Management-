import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import CandidateCard from '@/components/CandidateCard';
import { getAllUsers, getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase, cleanupOrphanedAssignments } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  ArrowLeft,
  TrendingUp,
  CheckCircle,
  Clock
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface TeamMemberDetailProps {
  onLogout?: () => void;
}

export default function TeamMemberDetail({ onLogout }: TeamMemberDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const [member, setMember] = useState<any>(null);
  const [assignedCandidates, setAssignedCandidates] = useState<any[]>([]);

  useEffect(() => {
    const updateMemberData = () => {
      // Clean up any orphaned assignments first
      cleanupOrphanedAssignments();
      
      const allUsers = getAllUsers();
      const user = allUsers.find(u => u.id === params.id);
      
      if (!user) {
        setMember(null);
        return;
      }
      
      // Get assignments for this team member
      const assignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
      
      console.log('TeamMemberDetail - All assignments:', assignments);
      console.log('TeamMemberDetail - Looking for user:', user.id, user.name);
      
      const memberAssignments = Object.entries(assignments)
        .filter(([_, assignment]: [string, any]) => assignment.assignedToId === user.id)
        .map(([candidateId, _]) => candidateId);
      
      console.log('TeamMemberDetail - Member assignments:', memberAssignments);
      
      // Get candidate details
      const candidateUsers = getCandidateUsers();
      const batchAssignments = getBatchAssignments();
      const batches = getAllBatches();
      
      const candidates = memberAssignments
        .map(candidateId => {
          const candidateUser = candidateUsers.find(c => c.id === candidateId);
          if (!candidateUser) return null;
          
          const batchAssignment = batchAssignments.find(a => a.userId === candidateId);
          if (!batchAssignment) return null;
          
          const batch = batches.find(b => b.id === batchAssignment.batchId);
          
          return {
            id: candidateUser.id,
            name: candidateUser.name,
            technology: batchAssignment.technology,
            batch: batch?.name || 'Unknown',
            phase: batchAssignment.phase,
            experience: batchAssignment.experience,
            progress: getProgressFromPhase(batchAssignment.phase),
          };
        })
        .filter(Boolean);
      
      console.log('TeamMemberDetail - Candidates found:', candidates);
      
      setAssignedCandidates(candidates);
      
      // Calculate statistics
      const assignedCount = candidates.length;
      const placements = candidates.filter((c: any) => c && c.phase === 'placed').length;
      const activeSubmissions = candidates.filter((c: any) => c && c.phase === 'marketing').length;
      const interviewsScheduled = Math.floor(activeSubmissions * 0.4); // Placeholder
      const performance = assignedCount > 0 
        ? Math.min(Math.round((placements / assignedCount) * 100 + 40), 100)
        : 0;
      
      // Calculate average placement time (placeholder)
      const avgDays = placements > 0 ? Math.floor(30 + Math.random() * 30) : 0;
      const avgPlacementTime = avgDays > 0 ? `${avgDays} days` : 'N/A';
      
      console.log('TeamMemberDetail - Final stats:', { assignedCount, placements, performance });
      
      setMember({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role === 'sales_employee' ? 'Sales Employee' : user.role,
        assignedCandidates: assignedCount,
        placements,
        performance,
        activeSubmissions,
        interviewsScheduled,
        avgPlacementTime,
      });
    };
    
    updateMemberData();
    
    // Add custom event listener for manual updates
    const handleCustomUpdate = () => {
      console.log('TeamMemberDetail - Custom update triggered');
      updateMemberData();
    };
    
    window.addEventListener('storage', updateMemberData);
    window.addEventListener('focus', updateMemberData);
    window.addEventListener('candidateAssignmentChanged', handleCustomUpdate);
    
    return () => {
      window.removeEventListener('storage', updateMemberData);
      window.removeEventListener('focus', updateMemberData);
      window.removeEventListener('candidateAssignmentChanged', handleCustomUpdate);
    };
  }, [params.id]);
  
  if (!member) {
    return (
      <DashboardLayout
        navItems={navItems}
        userName="Jane Smith"
        userRole="Sales Manager"
        onLogout={onLogout}
      >
        <div className="p-6">
          <p>Team member not found</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/manager/team')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">{member.name}</h1>
            <p className="text-muted-foreground mt-1">{member.email}</p>
          </div>
          <Badge variant="outline" className="bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20">
            {member.role}
          </Badge>
        </div>

        {/* Performance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Assigned Candidates</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{member.assignedCandidates}</div>
              <p className="text-xs text-muted-foreground mt-1">Active assignments</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Placements</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">{member.placements}</div>
              <p className="text-xs text-muted-foreground mt-1">This quarter</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Submissions</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{member.activeSubmissions}</div>
              <p className="text-xs text-muted-foreground mt-1">{member.interviewsScheduled} interviews scheduled</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Performance</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{member.performance}%</div>
              <Progress value={member.performance} className="h-2 mt-2" />
            </CardContent>
          </Card>
        </div>

        {/* Performance Metrics */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Metrics</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/10 rounded-lg">
                  <Clock className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Placement Time</p>
                  <p className="text-2xl font-bold">{member.avgPlacementTime}</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/10 rounded-lg">
                  <Target className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Success Rate</p>
                  <p className="text-2xl font-bold">
                    {member.assignedCandidates > 0 
                      ? Math.round((member.placements / member.assignedCandidates) * 100)
                      : 0}%
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Assigned Candidates */}
        <Card>
          <CardHeader>
            <CardTitle>Assigned Candidates ({assignedCandidates.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {assignedCandidates.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No candidates assigned yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {assignedCandidates.map((candidate: any) => (
                  <CandidateCard
                    key={candidate.id}
                    {...candidate}
                    onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
