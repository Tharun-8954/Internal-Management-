import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { getAllUsers, getBatchAssignments, getAllBatches, getProgressFromPhase, getSubmissionsByCandidate } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  ArrowLeft,
  Mail,
  Phone,
  Briefcase,
  Send
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

const phaseLabels: Record<string, string> = {
  training: 'Training',
  mock_interviews: 'Mock Interviews',
  marketing: 'Marketing',
  placed: 'Placed',
};

const phaseColors: Record<string, string> = {
  training: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
  mock_interviews: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20',
  marketing: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20',
  placed: 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20',
};

interface CandidateDetailProps {
  onLogout?: () => void;
}

export default function CandidateDetail({ onLogout }: CandidateDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const [candidate, setCandidate] = useState<any>(null);
  const [assignment, setAssignment] = useState<any>(null);
  const [batch, setBatch] = useState<any>(null);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [assignedTo, setAssignedTo] = useState<string>('Unassigned');

  useEffect(() => {
    loadCandidateData();
    
    window.addEventListener('storage', loadCandidateData);
    window.addEventListener('focus', loadCandidateData);
    
    return () => {
      window.removeEventListener('storage', loadCandidateData);
      window.removeEventListener('focus', loadCandidateData);
    };
  }, [params.id]);

  const loadCandidateData = () => {
    const allUsers = getAllUsers();
    const candidateUser = allUsers.find(u => u.id === params.id);
    
    if (!candidateUser) {
      setCandidate(null);
      return;
    }
    
    setCandidate(candidateUser);
    
    // Get batch assignment
    const batchAssignments = getBatchAssignments();
    const candidateAssignment = batchAssignments.find(a => a.userId === params.id);
    setAssignment(candidateAssignment);
    
    // Get batch details
    if (candidateAssignment) {
      const batches = getAllBatches();
      const candidateBatch = batches.find(b => b.id === candidateAssignment.batchId);
      setBatch(candidateBatch);
    }
    
    // Get submissions
    const candidateSubmissions = getSubmissionsByCandidate(params.id || '');
    setSubmissions(candidateSubmissions);
    
    // Get assignment to sales employee
    const candidateAssignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
    const salesAssignment = candidateAssignments[params.id || ''];
    if (salesAssignment) {
      setAssignedTo(salesAssignment.assignedTo);
    } else {
      setAssignedTo('Unassigned');
    }
  };

  if (!candidate) {
    return (
      <DashboardLayout
        navItems={navItems}
        userName="Jane Smith"
        userRole="Sales Manager"
        onLogout={onLogout}
      >
        <div className="p-6">
          <p>Candidate not found</p>
        </div>
      </DashboardLayout>
    );
  }

  const progress = assignment ? getProgressFromPhase(assignment.phase) : 0;
  const initials = candidate.name.split(' ').map((n: string) => n[0]).join('');

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/manager/dashboard')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Candidate Details</h1>
            <p className="text-muted-foreground mt-1">View candidate information and progress</p>
          </div>
          <Button onClick={() => setLocation('/manager/submissions')} data-testid="button-submit-candidate">
            <Send className="mr-2 h-4 w-4" />
            Create Submission
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Profile</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src="" alt={candidate.name} />
                  <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-semibold">{candidate.name}</h2>
                <p className="text-sm text-muted-foreground">
                  {assignment?.technology || 'Technology not assigned'}
                </p>
                {batch && (
                  <Badge variant="outline" className="mt-2 bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border-cyan-500/20">
                    {batch.name} Batch
                  </Badge>
                )}
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm">{candidate.email}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Briefcase className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">Experience</p>
                    <p className="text-sm">{assignment?.experience || 0} years</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Progress & Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Overall Progress</span>
                  <span className="text-sm text-muted-foreground">{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-500/10 rounded-md border border-green-500/20">
                  <p className="text-xs text-muted-foreground mb-1">Phase</p>
                  <p className="font-semibold">{assignment ? phaseLabels[assignment.phase] : 'Not Assigned'}</p>
                  {assignment && (
                    <Badge variant="outline" className={`mt-2 ${phaseColors[assignment.phase]}`}>
                      {assignment.phase === 'placed' ? 'Completed' : 'In Progress'}
                    </Badge>
                  )}
                </div>
                <div className="text-center p-4 border rounded-md">
                  <p className="text-xs text-muted-foreground mb-1">Assigned To</p>
                  <p className="font-semibold">{assignedTo}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {assignedTo !== 'Unassigned' ? 'Sales Employee' : 'Not assigned yet'}
                  </p>
                </div>
                <div className="text-center p-4 border rounded-md">
                  <p className="text-xs text-muted-foreground mb-1">Submissions</p>
                  <p className="text-3xl font-bold">{submissions.length}</p>
                </div>
              </div>

              {assignment && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Technology Focus</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="text-base px-3 py-1">
                        {assignment.technology}
                      </Badge>
                      {batch && (
                        <Badge variant="outline" className="text-base px-3 py-1">
                          {batch.name}
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
