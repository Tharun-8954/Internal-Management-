import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  FileText,
  UserCheck,
  Search,
  Mail,
  Target,
  UserPlus
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface AllCandidatesProps {
  onLogout?: () => void;
}

export default function AllCandidates({ onLogout }: AllCandidatesProps) {
  console.log('🔵 AllCandidates component loaded - TABLE VIEW');
  
  const [, setLocation] = useLocation();
  const [candidateUsers, setCandidateUsers] = useState(getCandidateUsers());
  const [assignments, setAssignments] = useState(getBatchAssignments());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBatch, setFilterBatch] = useState('all');
  const [filterPhase, setFilterPhase] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const batches = getAllBatches();

  useEffect(() => {
    const loadData = () => {
      setCandidateUsers(getCandidateUsers());
      setAssignments(getBatchAssignments());
    };

    loadData();
    
    window.addEventListener('storage', loadData);
    window.addEventListener('focus', loadData);
    
    return () => {
      window.removeEventListener('storage', loadData);
      window.removeEventListener('focus', loadData);
    };
  }, []);

  const filteredAndSortedCandidates = candidateUsers
    .filter(candidate => {
      const query = searchQuery.toLowerCase();
      const assignment = assignments.find(a => a.userId === candidate.id);
      const batch = assignment ? batches.find(b => b.id === assignment.batchId) : null;
      
      const matchesSearch = (
        candidate.name.toLowerCase().includes(query) ||
        candidate.email.toLowerCase().includes(query) ||
        batch?.name.toLowerCase().includes(query) ||
        assignment?.technology.toLowerCase().includes(query)
      );
      
      const matchesBatch = filterBatch === 'all' || 
        (filterBatch === 'unassigned' && !assignment) ||
        (assignment && assignment.batchId === filterBatch);
      
      const matchesPhase = filterPhase === 'all' || 
        (assignment && assignment.phase === filterPhase);
      
      return matchesSearch && matchesBatch && matchesPhase;
    })
    .sort((a, b) => {
      const assignmentA = assignments.find(asn => asn.userId === a.id);
      const assignmentB = assignments.find(asn => asn.userId === b.id);
      const batchA = assignmentA ? batches.find(b => b.id === assignmentA.batchId) : null;
      const batchB = assignmentB ? batches.find(b => b.id === assignmentB.batchId) : null;
      
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'email':
          return a.email.localeCompare(b.email);
        case 'batch':
          return (batchA?.name || 'ZZZ').localeCompare(batchB?.name || 'ZZZ');
        case 'phase':
          return (assignmentA?.phase || 'zzz').localeCompare(assignmentB?.phase || 'zzz');
        default:
          return 0;
      }
    });

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">📋 All Candidates - Detailed View</h1>
          <p className="text-muted-foreground mt-1">
            Complete list of all candidates with detailed information and filtering options
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Candidates</p>
                  <p className="text-2xl font-bold">{candidateUsers.length}</p>
                </div>
                <UserCheck className="h-8 w-8 text-muted-foreground opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Training</p>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {assignments.filter(a => a.phase === 'training').length}
                  </p>
                </div>
                <GraduationCap className="h-8 w-8 text-blue-600 dark:text-blue-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Marketing</p>
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                    {assignments.filter(a => a.phase === 'marketing').length}
                  </p>
                </div>
                <Target className="h-8 w-8 text-purple-600 dark:text-purple-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Placed</p>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {assignments.filter(a => a.phase === 'placed').length}
                  </p>
                </div>
                <UserCheck className="h-8 w-8 text-green-600 dark:text-green-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search candidates..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={filterBatch} onValueChange={setFilterBatch}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by batch" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Batches</SelectItem>
              {batches.map(batch => (
                <SelectItem key={batch.id} value={batch.id}>{batch.name}</SelectItem>
              ))}
              <SelectItem value="unassigned">Unassigned</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterPhase} onValueChange={setFilterPhase}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by phase" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Phases</SelectItem>
              <SelectItem value="training">Training</SelectItem>
              <SelectItem value="mock_interviews">Mock Interviews</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
              <SelectItem value="placed">Placed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="batch">Batch</SelectItem>
              <SelectItem value="phase">Phase</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Card>
          <CardContent className="p-0">
            {filteredAndSortedCandidates.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <UserCheck className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">No candidates found</p>
                <p className="text-sm mt-1">Try adjusting your filters</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-muted/50 border-b">
                    <tr>
                      <th className="text-left p-4 font-medium">Candidate</th>
                      <th className="text-left p-4 font-medium">Email</th>
                      <th className="text-left p-4 font-medium">Batch</th>
                      <th className="text-left p-4 font-medium">Technology</th>
                      <th className="text-left p-4 font-medium">Phase</th>
                      <th className="text-left p-4 font-medium">Experience</th>
                      <th className="text-left p-4 font-medium">Progress</th>
                      <th className="text-left p-4 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAndSortedCandidates.map(candidate => {
                      const assignment = assignments.find(a => a.userId === candidate.id);
                      const batch = assignment ? batches.find(b => b.id === assignment.batchId) : null;
                      
                      return (
                        <tr 
                          key={candidate.id} 
                          className="border-b hover:bg-muted/50 cursor-pointer transition-colors"
                          onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                        >
                          <td className="p-4">
                            <div className="font-medium">{candidate.name}</div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Mail className="h-3 w-3" />
                              {candidate.email}
                            </div>
                          </td>
                          <td className="p-4">
                            {batch ? (
                              <Badge variant="outline">{batch.name}</Badge>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="p-4">
                            {assignment ? (
                              <span className="text-sm">{assignment.technology}</span>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="p-4">
                            {assignment ? (
                              <Badge variant="outline" className="capitalize">
                                {assignment.phase.replace('_', ' ')}
                              </Badge>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="p-4">
                            {assignment ? (
                              <span className="text-sm">{assignment.experience} years</span>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="p-4">
                            {assignment ? (
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-primary transition-all"
                                    style={{ width: `${getProgressFromPhase(assignment.phase)}%` }}
                                  />
                                </div>
                                <span className="text-sm font-medium">{getProgressFromPhase(assignment.phase)}%</span>
                              </div>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="p-4">
                            <Badge variant={candidate.status === 'active' ? 'default' : 'secondary'}>
                              {candidate.status}
                            </Badge>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
