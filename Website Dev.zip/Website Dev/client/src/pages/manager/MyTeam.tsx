import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { getUsersByRole, getCandidateUsers, getBatchAssignments, cleanupOrphanedAssignments, getAllUsers } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface MyTeamProps {
  onLogout?: () => void;
}

export default function MyTeam({ onLogout }: MyTeamProps) {
  const [, setLocation] = useLocation();
  const [teamMembers, setTeamMembers] = useState<any[]>([]);

  useEffect(() => {
    const updateTeamMembers = () => {
      // Clean up any orphaned assignments first
      cleanupOrphanedAssignments();
      
      const salesEmployees = getUsersByRole('sales_employee');
      const salesManagers = getUsersByRole('sales_manager');
      
      // Combine sales employees and sales managers (manager can also manage candidates)
      const allTeamMembers = [...salesManagers, ...salesEmployees];
      
      const assignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
      const candidateUsers = getCandidateUsers();
      const batchAssignments = getBatchAssignments();
      
      console.log('MyTeam - Loading assignments:', assignments);
      console.log('MyTeam - All team members:', allTeamMembers);
      console.log('MyTeam - Candidate users:', candidateUsers);
      
      const membersWithStats = allTeamMembers.map(employee => {
        // Get candidate IDs assigned to this employee
        const assignedCandidateIds = Object.entries(assignments)
          .filter(([_, assignment]: [string, any]) => assignment.assignedToId === employee.id)
          .map(([candidateId, _]) => candidateId);
        
        // Count only candidates that still exist and have batch assignments
        const validAssignedCandidates = assignedCandidateIds.filter(candidateId => {
          const candidateExists = candidateUsers.some(c => c.id === candidateId);
          const hasBatchAssignment = batchAssignments.some(a => a.userId === candidateId);
          return candidateExists && hasBatchAssignment;
        }).length;
        
        console.log(`MyTeam - Employee ${employee.name} (${employee.id}) has ${validAssignedCandidates} valid assigned (${assignedCandidateIds.length} total)`);
        
        // Calculate placements (would come from submission system)
        const placements = Math.floor(validAssignedCandidates * 0.3); // Placeholder calculation
        
        // Calculate performance based on assignments and placements
        const performance = validAssignedCandidates > 0 
          ? Math.min(Math.round((placements / validAssignedCandidates) * 100 + Math.random() * 20), 100)
          : 0;
        
        return {
          id: employee.id,
          name: employee.name,
          email: employee.email,
          assignedCandidates: validAssignedCandidates,
          placements,
          performance,
        };
      });
      
      setTeamMembers(membersWithStats);
    };
    
    updateTeamMembers();
    
    // Add custom event listener for manual updates
    const handleCustomUpdate = () => {
      console.log('MyTeam - Custom update triggered');
      updateTeamMembers();
    };
    
    window.addEventListener('storage', updateTeamMembers);
    window.addEventListener('focus', updateTeamMembers);
    window.addEventListener('candidateAssignmentChanged', handleCustomUpdate);
    
    return () => {
      window.removeEventListener('storage', updateTeamMembers);
      window.removeEventListener('focus', updateTeamMembers);
      window.removeEventListener('candidateAssignmentChanged', handleCustomUpdate);
    };
  }, []);

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Team</h1>
          <p className="text-muted-foreground mt-1">
            Manage and monitor your sales team performance
          </p>
        </div>

        {teamMembers.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No team members yet</p>
            <p className="text-sm mt-1">Add sales employees in User Management</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {teamMembers.map((member) => (
            <Card key={member.id} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setLocation(`/manager/team/${member.id}`)} data-testid={`card-team-member-${member.id}`}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src="" alt={member.name} />
                    <AvatarFallback>{member.name.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-base">{member.name}</CardTitle>
                    <p className="text-xs text-muted-foreground">{member.email}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Assigned</p>
                    <p className="text-xl font-bold">{member.assignedCandidates}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Placements</p>
                    <p className="text-xl font-bold text-green-600 dark:text-green-400">{member.placements}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Performance</span>
                    <Badge variant="outline" className={member.performance >= 90 ? 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20' : member.performance >= 80 ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20' : 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20'}>
                      {member.performance}%
                    </Badge>
                  </div>
                  <Progress value={member.performance} className="h-2" />
                </div>
              </CardContent>
            </Card>
          ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
