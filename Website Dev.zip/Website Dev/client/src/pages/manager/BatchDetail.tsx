import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import CandidateCard from '@/components/CandidateCard';
import { Progress } from '@/components/ui/progress';
import { getBatchById, getCandidatesByBatch, getProgressFromPhase } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  ArrowLeft
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface BatchDetailProps {
  onLogout?: () => void;
}

export default function BatchDetail({ onLogout }: BatchDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const [batch, setBatch] = useState<any>(null);
  const [candidates, setCandidates] = useState<any[]>([]);

  useEffect(() => {
    loadBatchData();
    
    window.addEventListener('storage', loadBatchData);
    window.addEventListener('focus', loadBatchData);
    
    return () => {
      window.removeEventListener('storage', loadBatchData);
      window.removeEventListener('focus', loadBatchData);
    };
  }, [params.id]);

  const loadBatchData = () => {
    const batchData = getBatchById(params.id || '');
    setBatch(batchData);
    
    if (batchData) {
      const batchCandidates = getCandidatesByBatch(params.id || '');
      const candidatesWithProgress = batchCandidates.map(candidate => ({
        id: candidate.id,
        name: candidate.name,
        technology: candidate.technology,
        batch: batchData.name,
        phase: candidate.phase,
        experience: candidate.experience,
        progress: getProgressFromPhase(candidate.phase),
      }));
      setCandidates(candidatesWithProgress);
    }
  };

  if (!batch) {
    return (
      <DashboardLayout
        navItems={navItems}
        userName="Jane Smith"
        userRole="Sales Manager"
        onLogout={onLogout}
      >
        <div className="p-6">
          <p>Batch not found</p>
        </div>
      </DashboardLayout>
    );
  }

  const trainingPercentage = batch.totalCandidates > 0 
    ? Math.round((batch.trainingCount / batch.totalCandidates) * 100) 
    : 0;
  const mockInterviewPercentage = batch.totalCandidates > 0 
    ? Math.round((batch.mockInterviewCount / batch.totalCandidates) * 100) 
    : 0;
  const placedPercentage = batch.totalCandidates > 0 
    ? Math.round((batch.placedCount / batch.totalCandidates) * 100) 
    : 0;
  
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/manager/batches')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">{batch.name} Batch</h1>
            <p className="text-muted-foreground mt-1">{batch.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Candidates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{batch.totalCandidates}</div>
              <p className="text-xs text-muted-foreground mt-1">Active in batch</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Training</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {batch.trainingCount}
              </div>
              <Progress value={trainingPercentage} className="h-1.5 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Mock Interviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                {batch.mockInterviewCount}
              </div>
              <Progress value={mockInterviewPercentage} className="h-1.5 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Placed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {batch.placedCount}
              </div>
              <Progress value={placedPercentage} className="h-1.5 mt-2" />
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Batch Candidates ({candidates.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {candidates.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No candidates in this batch yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {candidates.map(candidate => (
                  <CandidateCard
                    key={candidate.id}
                    {...candidate}
                    onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
