import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import CandidateCard from '@/components/CandidateCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { getUsersByRole, getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase } from '@/lib/data-service';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  UserCog
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

// No hardcoded data - will pull from data service

interface AssignmentsProps {
  onLogout?: () => void;
}

export default function Assignments({ onLogout }: AssignmentsProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<any>(null);
  const [selectedTeamMember, setSelectedTeamMember] = useState<string>('');
  const [assignments, setAssignments] = useState<any>({});
  const [allCandidates, setAllCandidates] = useState<any[]>([]);
  
  // Get sales employees and managers from user management
  const salesEmployees = getUsersByRole('sales_employee');
  const salesManagers = getUsersByRole('sales_manager');
  const allTeamMembers = [...salesManagers, ...salesEmployees];
  const batches = getAllBatches();

  // Load candidates and assignments from localStorage
  useEffect(() => {
    // Get candidate users
    const candidateUsers = getCandidateUsers();
    const batchAssignments = getBatchAssignments();
    
    // Map candidates with their batch assignments
    const candidates = candidateUsers.map(user => {
      const assignment = batchAssignments.find(a => a.userId === user.id);
      const batch = assignment ? batches.find(b => b.id === assignment.batchId) : null;
      
      return assignment ? {
        id: user.id,
        name: user.name,
        technology: assignment.technology,
        batch: batch?.name || 'Unknown',
        phase: assignment.phase,
        experience: assignment.experience,
        progress: getProgressFromPhase(assignment.phase),
      } : null;
    }).filter(Boolean);
    
    setAllCandidates(candidates);
    
    // Load sales assignments
    const stored = localStorage.getItem('candidateAssignments');
    if (stored) {
      setAssignments(JSON.parse(stored));
    }
  }, []);

  const handleAssignClick = (candidate: any) => {
    setSelectedCandidate(candidate);
    setSelectedTeamMember('');
    setIsAssignDialogOpen(true);
  };

  const handleAssignConfirm = () => {
    if (!selectedTeamMember || !selectedCandidate) {
      toast({
        title: 'Error',
        description: 'Please select a team member',
        variant: 'destructive',
      });
      return;
    }

    const teamMember = allTeamMembers.find(e => e.id === selectedTeamMember);
    const newAssignments = {
      ...assignments,
      [selectedCandidate.id]: {
        candidateId: selectedCandidate.id,
        candidateName: selectedCandidate.name,
        assignedTo: teamMember?.name,
        assignedToId: selectedTeamMember,
        assignedAt: new Date().toISOString(),
      }
    };

    setAssignments(newAssignments);
    localStorage.setItem('candidateAssignments', JSON.stringify(newAssignments));

    toast({
      title: 'Success',
      description: `${selectedCandidate.name} assigned to ${teamMember?.name}`,
    });

    setIsAssignDialogOpen(false);
    setSelectedCandidate(null);
    setSelectedTeamMember('');
  };

  const handleUnassign = (candidateId: string, candidateName: string) => {
    const newAssignments = { ...assignments };
    delete newAssignments[candidateId];
    
    setAssignments(newAssignments);
    localStorage.setItem('candidateAssignments', JSON.stringify(newAssignments));
    
    // Dispatch custom event to notify other components
    window.dispatchEvent(new Event('candidateAssignmentChanged'));

    toast({
      title: 'Success',
      description: `${candidateName} unassigned`,
    });
  };

  // Separate candidates into assigned and unassigned
  const unassignedCandidates = allCandidates.filter(c => !assignments[c.id]);
  const assignedCandidates = allCandidates
    .filter(c => assignments[c.id])
    .map(c => ({
      ...c,
      assignedTo: assignments[c.id]?.assignedTo,
      assignedToId: assignments[c.id]?.assignedToId,
    }));

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Candidate Assignments</h1>
          <p className="text-muted-foreground mt-1">
            Assign candidates to your sales team members
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Unassigned Candidates</CardTitle>
          </CardHeader>
          <CardContent>
            {unassignedCandidates.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <UserCog className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>All candidates are assigned</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {unassignedCandidates.map(candidate => (
                  <div key={candidate.id} className="relative">
                    <CandidateCard
                      {...candidate}
                      onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                    />
                    <Button
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAssignClick(candidate);
                      }}
                      data-testid={`button-assign-${candidate.id}`}
                    >
                      <UserCog className="mr-1 h-3 w-3" />
                      Assign
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Currently Assigned</CardTitle>
          </CardHeader>
          <CardContent>
            {assignedCandidates.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No assigned candidates yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {assignedCandidates.map(candidate => (
                  <div key={candidate.id} className="space-y-2">
                    <CandidateCard
                      id={candidate.id}
                      name={candidate.name}
                      technology={candidate.technology}
                      batch={candidate.batch}
                      phase={candidate.phase}
                      experience={candidate.experience}
                      progress={candidate.progress}
                      onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                    />
                    <div className="flex items-center justify-between px-1">
                      <Badge variant="outline" className="text-xs">
                        {candidate.assignedTo}
                      </Badge>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAssignClick(candidate);
                          }}
                          data-testid={`button-reassign-${candidate.id}`}
                        >
                          Reassign
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUnassign(candidate.id, candidate.name);
                          }}
                        >
                          Unassign
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Candidate</DialogTitle>
            <DialogDescription>
              Select a sales employee to assign {selectedCandidate?.name} to
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-3 py-4">
            {allTeamMembers.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">
                <p>No team members available</p>
                <p className="text-sm mt-1">Add sales employees or managers in User Management</p>
              </div>
            ) : (
              allTeamMembers.map(employee => (
                <Card
                  key={employee.id}
                  className={`cursor-pointer transition-all ${
                    selectedTeamMember === employee.id
                      ? 'ring-2 ring-primary'
                      : 'hover:shadow-md'
                  }`}
                  onClick={() => setSelectedTeamMember(employee.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src="" alt={employee.name} />
                        <AvatarFallback>
                          {employee.name.split(' ').map((n: string) => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-semibold">{employee.name}</p>
                        <p className="text-sm text-muted-foreground">{employee.email}</p>
                      </div>
                      {selectedTeamMember === employee.id && (
                        <Badge>Selected</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAssignDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAssignConfirm} disabled={!selectedTeamMember}>
              Assign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
