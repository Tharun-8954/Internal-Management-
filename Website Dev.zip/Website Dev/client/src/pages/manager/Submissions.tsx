import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { format } from 'date-fns';
import DashboardLayout from '@/components/DashboardLayout';
import SubmissionTable from '@/components/SubmissionTable';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getAllSubmissions, createSubmission, getCandidateUsers, getBatchAssignments } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  Search,
  Plus,
  CalendarIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface SubmissionsProps {
  onLogout?: () => void;
}

export default function Submissions({ onLogout }: SubmissionsProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCandidate, setFilterCandidate] = useState('all');
  const [filterSubmittedBy, setFilterSubmittedBy] = useState('all');
  const [sortBy, setSortBy] = useState('date');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [candidates, setCandidates] = useState<any[]>([]);
  
  // Form state
  const [selectedCandidate, setSelectedCandidate] = useState('');
  const [company, setCompany] = useState('');
  const [submissionDate, setSubmissionDate] = useState<Date>();
  const [rate, setRate] = useState('');
  const [status, setStatus] = useState<string>('submitted');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadData();
    
    window.addEventListener('storage', loadData);
    window.addEventListener('focus', loadData);
    
    return () => {
      window.removeEventListener('storage', loadData);
      window.removeEventListener('focus', loadData);
    };
  }, []);

  const loadData = () => {
    const allSubmissions = getAllSubmissions();
    setSubmissions(allSubmissions);
    
    // Load candidates with batch assignments
    const candidateUsers = getCandidateUsers();
    const batchAssignments = getBatchAssignments();
    
    const candidatesWithBatch = candidateUsers
      .filter(user => batchAssignments.some(a => a.userId === user.id))
      .map(user => {
        const assignment = batchAssignments.find(a => a.userId === user.id);
        return {
          ...user,
          technology: assignment?.technology,
          phase: assignment?.phase,
        };
      });
    
    setCandidates(candidatesWithBatch);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCandidate || !company || !submissionDate || !rate || !status) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const candidate = candidates.find(c => c.id === selectedCandidate);
    if (!candidate) return;

    createSubmission({
      candidateId: selectedCandidate,
      candidateName: candidate.name,
      company,
      submissionDate: format(submissionDate, 'yyyy-MM-dd'),
      rate,
      status: status as any,
      notes,
      createdBy: 'Jane Smith', // Would come from auth context
    });

    toast({
      title: 'Success',
      description: 'Submission created successfully',
    });

    // Reset form
    setSelectedCandidate('');
    setCompany('');
    setSubmissionDate(undefined);
    setRate('');
    setStatus('submitted');
    setNotes('');
    setIsDialogOpen(false);
    
    loadData();
  };

  const uniqueSubmitters = Array.from(new Set(submissions.map(s => s.createdBy)));

  const filteredAndSortedSubmissions = submissions
    .filter(sub => {
      const matchesSearch = (
        sub.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sub.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sub.createdBy.toLowerCase().includes(searchQuery.toLowerCase())
      );
      
      const matchesStatus = filterStatus === 'all' || sub.status === filterStatus;
      const matchesCandidate = filterCandidate === 'all' || sub.candidateId === filterCandidate;
      const matchesSubmittedBy = filterSubmittedBy === 'all' || sub.createdBy === filterSubmittedBy;
      
      return matchesSearch && matchesStatus && matchesCandidate && matchesSubmittedBy;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'date':
          return new Date(b.submissionDate).getTime() - new Date(a.submissionDate).getTime();
        case 'candidate':
          return a.candidateName.localeCompare(b.candidateName);
        case 'company':
          return a.company.localeCompare(b.company);
        case 'status':
          return a.status.localeCompare(b.status);
        case 'submittedBy':
          return a.createdBy.localeCompare(b.createdBy);
        default:
          return 0;
      }
    });

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Submissions</h1>
          <p className="text-muted-foreground mt-1">
            Track all candidate submissions and their status
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search submissions..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-submissions"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="submitted">Submitted</SelectItem>
              <SelectItem value="initial_screening">Initial Screening</SelectItem>
              <SelectItem value="assessment">Assessment</SelectItem>
              <SelectItem value="interview">Interview</SelectItem>
              <SelectItem value="offer">Offer</SelectItem>
              <SelectItem value="placed">Placed</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterCandidate} onValueChange={setFilterCandidate}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by candidate" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Candidates</SelectItem>
              {candidates.map(candidate => (
                <SelectItem key={candidate.id} value={candidate.id}>
                  {candidate.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filterSubmittedBy} onValueChange={setFilterSubmittedBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Submitted By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Submitters</SelectItem>
              {uniqueSubmitters.map(submitter => (
                <SelectItem key={submitter} value={submitter}>
                  {submitter}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Date (Newest)</SelectItem>
              <SelectItem value="candidate">Candidate Name</SelectItem>
              <SelectItem value="company">Company</SelectItem>
              <SelectItem value="status">Status</SelectItem>
              <SelectItem value="submittedBy">Submitted By</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => setIsDialogOpen(true)} data-testid="button-add-submission">
            <Plus className="mr-2 h-4 w-4" />
            Add Submission
          </Button>
        </div>

        <SubmissionTable
          submissions={filteredAndSortedSubmissions}
          onViewDetails={(id) => setLocation(`/manager/submissions/${id}`)}
          showSubmittedBy={true}
        />
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Submission</DialogTitle>
            <DialogDescription>
              Submit a candidate to a company for consideration
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="candidate">Candidate *</Label>
              <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
                <SelectTrigger id="candidate">
                  <SelectValue placeholder="Select a candidate" />
                </SelectTrigger>
                <SelectContent>
                  {candidates.length === 0 ? (
                    <div className="p-2 text-sm text-muted-foreground">
                      No candidates available
                    </div>
                  ) : (
                    candidates.map(candidate => (
                      <SelectItem key={candidate.id} value={candidate.id}>
                        {candidate.name} - {candidate.technology}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="company">Company *</Label>
              <Input
                id="company"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="Enter company name"
              />
            </div>

            <div className="space-y-2">
              <Label>Submission Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !submissionDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {submissionDate ? format(submissionDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={submissionDate}
                    onSelect={setSubmissionDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="rate">Rate *</Label>
              <Input
                id="rate"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                placeholder="e.g., $85/hr or $120,000/year"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="submitted">Submitted</SelectItem>
                  <SelectItem value="initial_screening">Initial Screening</SelectItem>
                  <SelectItem value="assessment">Assessment</SelectItem>
                  <SelectItem value="interview">Interview</SelectItem>
                  <SelectItem value="offer">Offer</SelectItem>
                  <SelectItem value="placed">Placed</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any additional notes..."
                rows={3}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Create Submission</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
