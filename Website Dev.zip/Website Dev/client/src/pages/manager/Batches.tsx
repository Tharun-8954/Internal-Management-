import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import BatchCard from '@/components/BatchCard';
import { getAllBatches } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface BatchesProps {
  onLogout?: () => void;
}

export default function Batches({ onLogout }: BatchesProps) {
  const [, setLocation] = useLocation();
  const [batches, setBatches] = useState<any[]>([]);

  useEffect(() => {
    loadBatches();
    
    window.addEventListener('storage', loadBatches);
    window.addEventListener('focus', loadBatches);
    
    return () => {
      window.removeEventListener('storage', loadBatches);
      window.removeEventListener('focus', loadBatches);
    };
  }, []);

  const loadBatches = () => {
    const allBatches = getAllBatches();
    setBatches(allBatches);
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Training Batches</h1>
          <p className="text-muted-foreground mt-1">
            View all training batches and their progress
          </p>
        </div>

        {batches.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <GraduationCap className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No batches available</p>
            <p className="text-sm mt-1">Batches will appear here once created</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {batches.map(batch => (
              <BatchCard
                key={batch.id}
                id={batch.id}
                name={batch.name}
                description={batch.description}
                totalCandidates={batch.totalCandidates}
                trainingCount={batch.trainingCount}
                mockInterviewCount={batch.mockInterviewCount}
                marketingCount={batch.marketingCount}
                placedCount={batch.placedCount}
                isActive={batch.isActive}
                onViewDetails={() => setLocation(`/manager/batches/${batch.id}`)}
              />
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
