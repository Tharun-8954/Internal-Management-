import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import CandidateCard from '@/components/CandidateCard';
import { getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  FileText
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

const CURRENT_USER_ID = '3'; // Bob Johnson

interface MyCandidatesProps {
  onLogout?: () => void;
}

export default function MyCandidates({ onLogout }: MyCandidatesProps) {
  console.log('🔵 SALES EMPLOYEE - MY CANDIDATES PAGE LOADED');
  
  const [, setLocation] = useLocation();
  const [candidates, setCandidates] = useState<any[]>([]);

  useEffect(() => {
    loadCandidates();
    
    window.addEventListener('storage', loadCandidates);
    window.addEventListener('focus', loadCandidates);
    window.addEventListener('candidateAssignmentChanged', loadCandidates);
    
    return () => {
      window.removeEventListener('storage', loadCandidates);
      window.removeEventListener('focus', loadCandidates);
      window.removeEventListener('candidateAssignmentChanged', loadCandidates);
    };
  }, []);

  const loadCandidates = () => {
    const assignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
    const myAssignments = Object.entries(assignments)
      .filter(([_, assignment]: [string, any]) => assignment.assignedToId === CURRENT_USER_ID)
      .map(([candidateId, _]) => candidateId);
    
    const candidateUsers = getCandidateUsers();
    const batchAssignments = getBatchAssignments();
    const batches = getAllBatches();
    
    const myCandidates = myAssignments
      .map(candidateId => {
        const candidateUser = candidateUsers.find(c => c.id === candidateId);
        if (!candidateUser) return null;
        
        const batchAssignment = batchAssignments.find(a => a.userId === candidateId);
        if (!batchAssignment) return null;
        
        const batch = batches.find(b => b.id === batchAssignment.batchId);
        
        return {
          id: candidateUser.id,
          name: candidateUser.name,
          technology: batchAssignment.technology,
          batch: batch?.name || 'Unknown',
          phase: batchAssignment.phase,
          experience: batchAssignment.experience,
          progress: getProgressFromPhase(batchAssignment.phase),
        };
      })
      .filter(Boolean);
    
    setCandidates(myCandidates);
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">👥 My Candidates</h1>
          <p className="text-muted-foreground mt-1">
            View and manage your assigned candidates
          </p>
        </div>

        {candidates.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No candidates assigned yet</p>
            <p className="text-sm mt-1">Your manager will assign candidates to you</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {candidates.map(candidate => (
              <CandidateCard
                key={candidate.id}
                {...candidate}
                onClick={() => setLocation(`/sales/candidates/${candidate.id}`)}
              />
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
