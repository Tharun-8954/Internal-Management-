import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import SubmissionTable from '@/components/SubmissionTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { getAllSubmissions } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  Search,
  Send
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

const CURRENT_USER_NAME = 'Bob Johnson';

interface SubmissionsProps {
  onLogout?: () => void;
}

export default function Submissions({ onLogout }: SubmissionsProps) {
  console.log('🟢 SALES EMPLOYEE - SUBMISSIONS PAGE LOADED');
  
  const [, setLocation] = useLocation();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadSubmissions();
    
    window.addEventListener('storage', loadSubmissions);
    window.addEventListener('focus', loadSubmissions);
    
    return () => {
      window.removeEventListener('storage', loadSubmissions);
      window.removeEventListener('focus', loadSubmissions);
    };
  }, []);

  const loadSubmissions = () => {
    const allSubmissions = getAllSubmissions();
    const mySubmissions = allSubmissions.filter(sub => sub.createdBy === CURRENT_USER_NAME);
    setSubmissions(mySubmissions);
  };

  const filteredSubmissions = submissions.filter(sub =>
    sub.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    sub.company.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">📄 My Submissions</h1>
            <p className="text-muted-foreground mt-1">
              Track all your candidate submissions
            </p>
          </div>
          <Button onClick={() => setLocation('/sales/submissions/new')} data-testid="button-new-submission">
            <Send className="mr-2 h-4 w-4" />
            New Submission
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search submissions..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-submissions"
            />
          </div>
        </div>

        {filteredSubmissions.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <FileText className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium">No submissions yet</p>
            <p className="text-sm mt-1">Create your first submission</p>
            <Button 
              onClick={() => setLocation('/sales/submissions/new')} 
              className="mt-4"
              variant="outline"
            >
              <Send className="mr-2 h-4 w-4" />
              New Submission
            </Button>
          </div>
        ) : (
          <SubmissionTable
            submissions={filteredSubmissions}
            onViewDetails={(id) => setLocation(`/sales/submissions/${id}`)}
          />
        )}
      </div>
    </DashboardLayout>
  );
}
