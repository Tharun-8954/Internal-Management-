import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { format } from 'date-fns';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { getCandidateUsers, getBatchAssignments, createSubmission } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  ArrowLeft,
  Send,
  CalendarIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

const CURRENT_USER_ID = '3'; // Bob Johnson

interface NewSubmissionProps {
  onLogout?: () => void;
}

export default function NewSubmission({ onLogout }: NewSubmissionProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [candidates, setCandidates] = useState<any[]>([]);
  
  const [selectedCandidate, setSelectedCandidate] = useState('');
  const [company, setCompany] = useState('');
  const [submissionDate, setSubmissionDate] = useState<Date>();
  const [rate, setRate] = useState('');
  const [status, setStatus] = useState('submitted');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadCandidates();
  }, []);

  const loadCandidates = () => {
    const assignments = JSON.parse(localStorage.getItem('candidateAssignments') || '{}');
    const myAssignments = Object.entries(assignments)
      .filter(([_, assignment]: [string, any]) => assignment.assignedToId === CURRENT_USER_ID)
      .map(([candidateId, _]) => candidateId);
    
    const candidateUsers = getCandidateUsers();
    const batchAssignments = getBatchAssignments();
    
    const myCandidates = myAssignments
      .map(candidateId => {
        const candidateUser = candidateUsers.find(c => c.id === candidateId);
        if (!candidateUser) return null;
        
        const batchAssignment = batchAssignments.find(a => a.userId === candidateId);
        if (!batchAssignment) return null;
        
        return {
          id: candidateUser.id,
          name: candidateUser.name,
          technology: batchAssignment.technology,
        };
      })
      .filter(Boolean);
    
    setCandidates(myCandidates);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCandidate || !company || !submissionDate || !rate || !status) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const candidate = candidates.find(c => c.id === selectedCandidate);
    if (!candidate) return;

    createSubmission({
      candidateId: selectedCandidate,
      candidateName: candidate.name,
      company,
      submissionDate: format(submissionDate, 'yyyy-MM-dd'),
      rate,
      status: status as any,
      notes,
      createdBy: 'Bob Johnson',
    });

    toast({
      title: 'Success',
      description: 'Submission created successfully',
    });

    setLocation('/sales/submissions');
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/sales/dashboard')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">New Submission</h1>
            <p className="text-muted-foreground mt-1">
              Submit a candidate to a client company
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <Card className="max-w-3xl">
            <CardHeader>
              <CardTitle>Submission Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="candidate">Candidate *</Label>
                <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
                  <SelectTrigger data-testid="select-candidate">
                    <SelectValue placeholder="Select candidate" />
                  </SelectTrigger>
                  <SelectContent>
                    {candidates.length === 0 ? (
                      <div className="p-2 text-sm text-muted-foreground">
                        No candidates assigned
                      </div>
                    ) : (
                      candidates.map(candidate => (
                        <SelectItem key={candidate.id} value={candidate.id}>
                          {candidate.name} - {candidate.technology}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="company">Company Name *</Label>
                <Input 
                  id="company" 
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Enter company name" 
                  data-testid="input-company" 
                />
              </div>

              <div className="space-y-2">
                <Label>Submission Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !submissionDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {submissionDate ? format(submissionDate, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={submissionDate}
                      onSelect={setSubmissionDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="rate">Rate *</Label>
                <Input 
                  id="rate" 
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  placeholder="e.g., $85/hr or $120,000/year" 
                  data-testid="input-rate" 
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="submitted">Submitted</SelectItem>
                    <SelectItem value="initial_screening">Initial Screening</SelectItem>
                    <SelectItem value="assessment">Assessment</SelectItem>
                    <SelectItem value="interview">Interview</SelectItem>
                    <SelectItem value="offer">Offer</SelectItem>
                    <SelectItem value="placed">Placed</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any additional notes..."
                  rows={3}
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button type="submit" data-testid="button-submit">
                  <Send className="mr-2 h-4 w-4" />
                  Create Submission
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setLocation('/sales/dashboard')}
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>
    </DashboardLayout>
  );
}
