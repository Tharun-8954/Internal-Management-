import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { format } from 'date-fns';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { getSubmissionById, updateSubmission } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  ArrowLeft,
  Building2,
  DollarSign,
  Calendar,
  User,
  MessageSquare,
  Save,
  ChevronRight,
  Trash2,
  Edit
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

const statusOrder = ['submitted', 'initial_screening', 'assessment', 'interview', 'offer', 'placed', 'rejected'];
const statusLabels: Record<string, string> = {
  submitted: 'Submitted',
  initial_screening: 'Initial Screening',
  assessment: 'Assessment',
  interview: 'Interview',
  offer: 'Offer Received',
  placed: 'Placed',
  rejected: 'Rejected',
};

const statusColors: Record<string, string> = {
  submitted: 'bg-gray-500',
  initial_screening: 'bg-blue-500',
  assessment: 'bg-yellow-500',
  interview: 'bg-purple-500',
  offer: 'bg-orange-500',
  placed: 'bg-green-500',
  rejected: 'bg-red-500',
};

interface SubmissionDetailProps {
  onLogout?: () => void;
}

export default function SubmissionDetail({ onLogout }: SubmissionDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const { toast } = useToast();
  const [submission, setSubmission] = useState<any>(null);
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [isChangingStatus, setIsChangingStatus] = useState(false);
  const [targetStatus, setTargetStatus] = useState<string>('');
  const [statusChangeNote, setStatusChangeNote] = useState('');
  const [editingNoteIndex, setEditingNoteIndex] = useState<number | null>(null);
  const [editedNoteText, setEditedNoteText] = useState('');
  const [deletingNoteIndex, setDeletingNoteIndex] = useState<number | null>(null);
  const [isAddingComment, setIsAddingComment] = useState(false);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    loadSubmission();
  }, [params.id]);

  const loadSubmission = () => {
    const sub = getSubmissionById(params.id || '');
    setSubmission(sub);
  };

  const parseNotes = (notesString: string) => {
    if (!notesString) return [];
    const noteBlocks = notesString.split('\n\n');
    return noteBlocks.map((block, index) => ({
      id: index,
      text: block
    }));
  };

  const parseComments = (commentsString: string) => {
    if (!commentsString) return [];
    const commentBlocks = commentsString.split('\n\n');
    return commentBlocks.map((block, index) => ({
      id: index,
      text: block
    }));
  };

  const handleAddComment = () => {
    if (!submission || !newComment.trim()) return;

    const updatedComments = submission.comments 
      ? `${submission.comments}\n\n[${format(new Date(), 'PPP p')}] Bob Johnson (Sales Employee):\n${newComment}`
      : `[${format(new Date(), 'PPP p')}] Bob Johnson (Sales Employee):\n${newComment}`;

    updateSubmission(submission.id, { comments: updatedComments });

    toast({
      title: 'Success',
      description: 'Comment sent to manager',
    });

    setNewComment('');
    setIsAddingComment(false);
    loadSubmission();
  };

  const handleAddNote = () => {
    if (!submission || !newNote.trim()) return;

    const updatedNotes = submission.notes 
      ? `${submission.notes}\n\n[${format(new Date(), 'PPP')}] ${newNote}`
      : `[${format(new Date(), 'PPP')}] ${newNote}`;

    updateSubmission(submission.id, { notes: updatedNotes });

    toast({
      title: 'Success',
      description: 'Note added successfully',
    });

    setNewNote('');
    setIsAddingNote(false);
    loadSubmission();
  };

  const handleDeleteNote = (noteIndex: number) => {
    setDeletingNoteIndex(noteIndex);
  };

  const confirmDeleteNote = () => {
    if (!submission || deletingNoteIndex === null) return;
    
    const notes = parseNotes(submission.notes);
    const updatedNotes = notes
      .filter((_, index) => index !== deletingNoteIndex)
      .map(note => note.text)
      .join('\n\n');

    updateSubmission(submission.id, { notes: updatedNotes });

    toast({
      title: 'Success',
      description: 'Note deleted successfully',
    });

    setDeletingNoteIndex(null);
    loadSubmission();
  };

  const handleEditNote = (noteIndex: number) => {
    const notes = parseNotes(submission.notes);
    setEditingNoteIndex(noteIndex);
    setEditedNoteText(notes[noteIndex].text);
  };

  const handleSaveEditedNote = () => {
    if (!submission || editingNoteIndex === null) return;

    const notes = parseNotes(submission.notes);
    notes[editingNoteIndex].text = editedNoteText;
    
    const updatedNotes = notes.map(note => note.text).join('\n\n');

    updateSubmission(submission.id, { notes: updatedNotes });

    toast({
      title: 'Success',
      description: 'Note updated successfully',
    });

    setEditingNoteIndex(null);
    setEditedNoteText('');
    loadSubmission();
  };

  const handleStatusChange = (newStatus: string) => {
    setTargetStatus(newStatus);
    setStatusChangeNote('');
    setIsChangingStatus(true);
  };

  const confirmStatusChange = () => {
    if (!submission || !targetStatus) return;

    const statusChangeLog = `[${format(new Date(), 'PPP p')}] Status changed from "${statusLabels[submission.status]}" to "${statusLabels[targetStatus]}" by Bob Johnson${statusChangeNote.trim() ? `\nNote: ${statusChangeNote}` : ''}`;
    
    const updatedNotes = submission.notes 
      ? `${submission.notes}\n\n${statusChangeLog}`
      : statusChangeLog;

    updateSubmission(submission.id, { 
      status: targetStatus as any,
      notes: updatedNotes 
    });

    toast({
      title: 'Status Updated',
      description: `Submission status changed to ${statusLabels[targetStatus]}`,
    });

    setIsChangingStatus(false);
    setTargetStatus('');
    setStatusChangeNote('');
    loadSubmission();
  };

  if (!submission) {
    return (
      <DashboardLayout
        navItems={navItems}
        userName="Bob Johnson"
        userRole="Sales Employee"
        onLogout={onLogout}
      >
        <div className="p-6">
          <p>Submission not found</p>
        </div>
      </DashboardLayout>
    );
  }

  const currentStatusIndex = statusOrder.indexOf(submission.status);
  const isRejected = submission.status === 'rejected';

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/sales/submissions')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Submission Details</h1>
            <p className="text-muted-foreground mt-1">
              {submission.candidateName} at {submission.company}
            </p>
          </div>
          <Badge variant="outline" className={`capitalize ${statusColors[submission.status]}/10 text-${statusColors[submission.status].replace('bg-', '')} border-${statusColors[submission.status].replace('bg-', '')}/20`}>
            {statusLabels[submission.status]}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Submission Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Candidate</p>
                  <p className="text-sm font-medium">{submission.candidateName}</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <Building2 className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Company</p>
                  <p className="text-sm font-medium">{submission.company}</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <DollarSign className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Rate</p>
                  <p className="text-sm font-medium">{submission.rate}</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Submission Date</p>
                  <p className="text-sm font-medium">{format(new Date(submission.submissionDate), 'PPP')}</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Submitted By</p>
                  <p className="text-sm font-medium">{submission.createdBy}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status Timeline</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {statusOrder.map((status, index) => {
                const isPast = index < currentStatusIndex || (isRejected && status === 'rejected');
                const isCurrent = index === currentStatusIndex;
                const isFuture = index > currentStatusIndex && !isRejected;
                const canMoveToThis = !isCurrent;
                
                return (
                  <div key={status} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`h-2 w-2 rounded-full ${
                        isCurrent ? 'bg-green-500' : isPast ? statusColors[status] : 'bg-gray-300 dark:bg-gray-700'
                      }`} />
                      {index < statusOrder.length - 1 && (
                        <div className={`h-full w-px ${
                          isPast ? statusColors[status] + '/30' : 'bg-gray-300 dark:bg-gray-700'
                        }`} />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <p className={`text-sm font-medium ${isFuture ? 'text-muted-foreground' : ''}`}>
                            {statusLabels[status]}
                          </p>
                          {isCurrent && (
                            <p className="text-xs text-muted-foreground">Current Status</p>
                          )}
                        </div>
                        {canMoveToThis && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleStatusChange(status)}
                            className="h-7 text-xs"
                          >
                            <ChevronRight className="h-3 w-3 mr-1" />
                            {isPast ? 'Revert' : 'Move Here'}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Notes & Comments</CardTitle>
              {!isAddingNote && (
                <Button size="sm" onClick={() => setIsAddingNote(true)}>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Add Note
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {isAddingNote && (
              <div className="space-y-2 p-4 border rounded-lg bg-muted/50">
                <Label>New Note</Label>
                <Textarea
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Add a note about this submission..."
                  rows={3}
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={handleAddNote}>
                    <Save className="mr-2 h-4 w-4" />
                    Save Note
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => {
                    setIsAddingNote(false);
                    setNewNote('');
                  }}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
            
            {submission.notes ? (
              <div className="space-y-3">
                {parseNotes(submission.notes).map((note, index) => (
                  <div key={note.id} className="p-4 border rounded-lg bg-muted/30 relative group">
                    {editingNoteIndex === index ? (
                      <div className="space-y-2">
                        <Textarea
                          value={editedNoteText}
                          onChange={(e) => setEditedNoteText(e.target.value)}
                          rows={3}
                        />
                        <div className="flex gap-2">
                          <Button size="sm" onClick={handleSaveEditedNote}>
                            <Save className="mr-2 h-3 w-3" />
                            Save
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => {
                            setEditingNoteIndex(null);
                            setEditedNoteText('');
                          }}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="whitespace-pre-wrap text-sm pr-20">
                          {note.text}
                        </div>
                        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleEditNote(index)}
                            className="h-7 w-7 p-0"
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleDeleteNote(index)}
                            className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                No notes added yet
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Comments to Manager</CardTitle>
              {!isAddingComment && (
                <Button size="sm" onClick={() => setIsAddingComment(true)}>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Add Comment
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {isAddingComment && (
              <div className="space-y-2 p-4 border rounded-lg bg-muted/50">
                <Label>New Comment</Label>
                <Textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Send a message to your manager about this submission..."
                  rows={3}
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={handleAddComment}>
                    <Save className="mr-2 h-4 w-4" />
                    Send Comment
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => {
                    setIsAddingComment(false);
                    setNewComment('');
                  }}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
            
            {submission.comments ? (
              <div className="space-y-3">
                {parseComments(submission.comments).map((comment) => (
                  <div key={comment.id} className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                    <div className="whitespace-pre-wrap text-sm">
                      {comment.text}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                No comments yet. Add a comment to communicate with your manager.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isChangingStatus} onOpenChange={setIsChangingStatus}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Submission Status</DialogTitle>
            <DialogDescription>
              Moving from "{statusLabels[submission?.status]}" to "{statusLabels[targetStatus]}"
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="status-note">Add Note (Optional)</Label>
              <Textarea
                id="status-note"
                value={statusChangeNote}
                onChange={(e) => setStatusChangeNote(e.target.value)}
                placeholder="Add details about this status change..."
                rows={4}
              />
              <p className="text-xs text-muted-foreground">
                This note will be automatically added to the submission history with timestamp.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsChangingStatus(false)}>
              Cancel
            </Button>
            <Button onClick={confirmStatusChange}>
              Confirm Status Change
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deletingNoteIndex !== null} onOpenChange={(open) => !open && setDeletingNoteIndex(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Note</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this note? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingNoteIndex(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDeleteNote}>
              Delete Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
