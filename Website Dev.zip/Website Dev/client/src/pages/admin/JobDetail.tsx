import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { format } from 'date-fns';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { getJobById, getJobApplicationsByJob, updateJobApplication, type Job, type JobApplication } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserCheck, 
  FileText,
  Briefcase,
  ArrowLeft,
  MapPin,
  DollarSign,
  Clock,
  Video,
  Briefcase as JobIcon,
  User,
  ExternalLink
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Submissions', url: '/admin/submissions', icon: FileText },
  { title: 'Interviews', url: '/admin/interviews', icon: Video },
  { title: 'Jobs', url: '/admin/jobs', icon: JobIcon },
  { title: 'Assignments', url: '/admin/assignments', icon: Briefcase },
];

interface JobDetailProps {
  onLogout?: () => void;
}

export default function JobDetail({ onLogout }: JobDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const { toast } = useToast();
  const [job, setJob] = useState<Job | null>(null);
  const [applications, setApplications] = useState<JobApplication[]>([]);

  useEffect(() => {
    loadJobData();
  }, [params.id]);

  const loadJobData = () => {
    const jobData = getJobById(params.id || '');
    if (jobData) {
      setJob(jobData);
      const apps = getJobApplicationsByJob(params.id || '');
      setApplications(apps);
    }
  };

  const handleUpdateApplicationStatus = (appId: string, status: JobApplication['status']) => {
    updateJobApplication(appId, { status });
    toast({
      title: 'Success',
      description: 'Application status updated',
    });
    loadJobData();
  };

  if (!job) {
    return (
      <DashboardLayout
        navItems={navItems}
        userName="John Doe"
        userRole="Admin"
        onLogout={onLogout}
      >
        <div className="p-6">
          <p>Job not found</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout
      navItems={navItems}
      userName="John Doe"
      userRole="Admin"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/admin/jobs')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">{job.title}</h1>
            <p className="text-muted-foreground mt-1">{job.company}</p>
          </div>
          <Badge variant={job.status === 'active' ? 'default' : 'secondary'} className="text-base px-4 py-2">
            {job.status}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Job Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="capitalize">{job.type}</span>
                </div>
                {job.salary && (
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span>{job.salary}</span>
                  </div>
                )}
              </div>

              {job.jobLink && (
                <>
                  <Separator />
                  <div>
                    <h3 className="font-semibold mb-2">Company Job Posting</h3>
                    <a 
                      href={job.jobLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-sm text-primary hover:underline"
                    >
                      <ExternalLink className="h-4 w-4" />
                      View on company website
                    </a>
                  </div>
                </>
              )}

              <Separator />

              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{job.description}</p>
              </div>

              <Separator />

              <div>
                <h3 className="font-semibold mb-2">Requirements</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{job.requirements}</p>
              </div>

              <Separator />

              <div className="text-sm text-muted-foreground">
                <p>Posted by {job.postedBy} on {format(new Date(job.postedDate), 'PPP')}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Applications ({applications.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {applications.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No applications yet
                </p>
              ) : (
                applications.map(app => {
                  const initials = app.candidateName.split(' ').map(n => n[0]).join('');
                  const statusColors = {
                    pending: 'bg-gray-100 text-gray-700 border-gray-300',
                    reviewed: 'bg-blue-100 text-blue-700 border-blue-300',
                    shortlisted: 'bg-green-100 text-green-700 border-green-300',
                    rejected: 'bg-red-100 text-red-700 border-red-300',
                  };
                  
                  return (
                    <div key={app.id} className="p-4 border rounded-lg space-y-3 hover:shadow-sm transition-shadow">
                      <div className="flex items-start gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                            {initials}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{app.candidateName}</p>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                            <User className="h-3 w-3" />
                            <span>Applied by: <span className="font-medium">{app.appliedBy}</span></span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(app.appliedDate), 'MMM dd, yyyy')}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge 
                          variant="outline" 
                          className={`text-xs capitalize ${statusColors[app.status]}`}
                        >
                          {app.status}
                        </Badge>
                        <Badge variant="secondary" className="text-xs capitalize">
                          {app.appliedByRole.replace('_', ' ')}
                        </Badge>
                      </div>
                      
                      {app.status === 'pending' && (
                        <div className="flex gap-2 pt-2 border-t">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="flex-1 text-xs h-8"
                            onClick={() => handleUpdateApplicationStatus(app.id, 'reviewed')}
                          >
                            Mark Reviewed
                          </Button>
                          <Button 
                            size="sm" 
                            className="flex-1 text-xs h-8"
                            onClick={() => handleUpdateApplicationStatus(app.id, 'shortlisted')}
                          >
                            Shortlist
                          </Button>
                        </div>
                      )}
                      
                      {app.status === 'reviewed' && (
                        <div className="flex gap-2 pt-2 border-t">
                          <Button 
                            size="sm" 
                            className="flex-1 text-xs h-8"
                            onClick={() => handleUpdateApplicationStatus(app.id, 'shortlisted')}
                          >
                            Shortlist
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive" 
                            className="flex-1 text-xs h-8"
                            onClick={() => handleUpdateApplicationStatus(app.id, 'rejected')}
                          >
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
