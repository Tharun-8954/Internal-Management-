import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { initialMockUsers } from '@/lib/data-service';
import { ArrowLeft, Save } from 'lucide-react';
import { adminNavItems } from '@/lib/admin-nav';

const navItems = adminNavItems;

interface UserDetailProps {
  onLogout?: () => void;
}

export default function UserDetail({ onLogout }: UserDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const { toast } = useToast();
  
  // Detect if we're in creation mode
  const isNewUser = params.id === 'new';
  
  // Form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('candidate');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  // Load user data when component mounts or params change
  useEffect(() => {
    if (isNewUser) {
      // Reset form for new user
      setFirstName('');
      setLastName('');
      setEmail('');
      setRole('candidate');
      setStatus('active');
    } else {
      // Load existing user data
      const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
      const modifiedInitialUsers = JSON.parse(localStorage.getItem('modifiedInitialUsers') || '[]');
      
      // Check if this is a modified initial user (prioritize localStorage version)
      let existingUser = storedUsers.find((u: any) => u.id === params.id);
      
      // If not found in stored users and not modified, check initial users
      if (!existingUser && !modifiedInitialUsers.includes(params.id)) {
        existingUser = initialMockUsers.find(u => u.id === params.id);
      }
      
      if (existingUser) {
        const nameParts = existingUser.name.split(' ');
        setFirstName(nameParts[0] || '');
        setLastName(nameParts.slice(1).join(' ') || '');
        setEmail(existingUser.email || '');
        setRole(existingUser.role || 'candidate');
        setStatus(existingUser.status || 'active');
      }
    }
  }, [params.id, isNewUser]);

  const handleSave = () => {
    // Validate form
    if (!firstName.trim() || !lastName.trim() || !email.trim()) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const updatedUser = {
      id: isNewUser ? Date.now().toString() : params.id,
      name: `${firstName} ${lastName}`,
      email,
      role,
      status,
    };

    // Get existing users from localStorage
    const storedUsers = JSON.parse(localStorage.getItem('users') || '[]');
    
    if (isNewUser) {
      // Add new user
      storedUsers.push(updatedUser);
      localStorage.setItem('users', JSON.stringify(storedUsers));
      
      toast({
        title: 'Success',
        description: 'User created successfully',
      });
    } else {
      // Check if user is in localStorage (custom user) or initial mock users
      const userIndex = storedUsers.findIndex((u: any) => u.id === params.id);
      const isInitialUser = initialMockUsers.some(u => u.id === params.id);
      
      if (userIndex >= 0) {
        // Update existing custom user
        storedUsers[userIndex] = updatedUser;
        localStorage.setItem('users', JSON.stringify(storedUsers));
      } else if (isInitialUser) {
        // Initial user being edited - add to localStorage as modified
        storedUsers.push(updatedUser);
        localStorage.setItem('users', JSON.stringify(storedUsers));
        // Also store which initial users have been modified
        const modifiedInitialUsers = JSON.parse(localStorage.getItem('modifiedInitialUsers') || '[]');
        if (!modifiedInitialUsers.includes(params.id)) {
          modifiedInitialUsers.push(params.id);
          localStorage.setItem('modifiedInitialUsers', JSON.stringify(modifiedInitialUsers));
        }
      }
      
      toast({
        title: 'Success',
        description: 'User updated successfully',
      });
    }
    
    setLocation('/admin/users');
  };
  
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/admin/users')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{isNewUser ? 'Create New User' : 'User Details'}</h1>
            <p className="text-muted-foreground mt-1">
              {isNewUser ? 'Add a new user to the system' : 'Edit user information and permissions'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Profile</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              <Avatar className="h-24 w-24">
                <AvatarImage src="" alt="User" />
                <AvatarFallback className="text-2xl">
                  {isNewUser ? '?' : `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <Badge variant="outline" className="bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20">
                {isNewUser ? 'New User' : role.replace('_', ' ').split(' ').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
              </Badge>
              {!isNewUser && (
                <p className="text-sm text-muted-foreground">User ID: {params.id}</p>
              )}
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>User Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input 
                    id="firstName" 
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    data-testid="input-first-name" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input 
                    id="lastName" 
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    data-testid="input-last-name" 
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  data-testid="input-email" 
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger data-testid="select-role">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrator</SelectItem>
                    <SelectItem value="sales_manager">Sales Manager</SelectItem>
                    <SelectItem value="sales_employee">Sales Employee</SelectItem>
                    <SelectItem value="candidate">Candidate</SelectItem>
                    <SelectItem value="developer">Developer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={status} onValueChange={(value) => setStatus(value as 'active' | 'inactive')}>
                  <SelectTrigger data-testid="select-status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2 pt-4">
                <Button onClick={handleSave} data-testid="button-save">
                  <Save className="mr-2 h-4 w-4" />
                  {isNewUser ? 'Create User' : 'Save Changes'}
                </Button>
                <Button variant="outline" onClick={() => setLocation('/admin/users')} data-testid="button-cancel">
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
