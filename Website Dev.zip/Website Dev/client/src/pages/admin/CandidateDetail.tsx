import { useState, useEffect } from 'react';
import { useLocation, useParams, useSearch } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { getCandidateById, getAllBatches, updateBatchCandidateCounts } from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  FileText,
  UserCheck,
  ArrowLeft,
  Save,
  Briefcase
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Submissions', url: '/admin/submissions', icon: FileText },
  { title: 'Assignments', url: '/admin/assignments', icon: Briefcase },
];

interface CandidateDetailProps {
  onLogout?: () => void;
}

export default function CandidateDetail({ onLogout }: CandidateDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const search = useSearch();
  const { toast } = useToast();
  
  const isNewCandidate = params.id === 'new';
  const batchIdFromUrl = new URLSearchParams(search).get('batchId');
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [technology, setTechnology] = useState('');
  const [batchId, setBatchId] = useState(batchIdFromUrl || '');
  const [phase, setPhase] = useState<'training' | 'mock_interviews' | 'marketing' | 'placed'>('training');
  const [experience, setExperience] = useState(0);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  
  const batches = getAllBatches();

  useEffect(() => {
    if (!isNewCandidate) {
      const candidate = getCandidateById(params.id || '');
      if (candidate) {
        setName(candidate.name);
        setEmail(candidate.email);
        setTechnology(candidate.technology);
        setBatchId(candidate.batchId);
        setPhase(candidate.phase);
        setExperience(candidate.experience);
        setProgress(candidate.progress);
        setStatus(candidate.status);
      }
    }
  }, [params.id, isNewCandidate]);

  const handleSave = () => {
    if (!name.trim() || !email.trim() || !technology.trim() || !batchId) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const candidateData = {
      id: isNewCandidate ? Date.now().toString() : params.id,
      name,
      email,
      technology,
      batchId,
      phase,
      experience,
      progress,
      status,
    };

    const storedCandidates = JSON.parse(localStorage.getItem('candidates') || '[]');
    
    if (isNewCandidate) {
      storedCandidates.push(candidateData);
      localStorage.setItem('candidates', JSON.stringify(storedCandidates));
      
      // Update batch candidate counts
      updateBatchCandidateCounts(batchId);
      
      toast({
        title: 'Success',
        description: 'Candidate created successfully',
      });
    } else {
      const candidateIndex = storedCandidates.findIndex((c: any) => c.id === params.id);
      const oldBatchId = storedCandidates[candidateIndex]?.batchId;
      
      if (candidateIndex >= 0) {
        storedCandidates[candidateIndex] = candidateData;
        localStorage.setItem('candidates', JSON.stringify(storedCandidates));
        
        // Update batch counts for both old and new batch if batch changed
        if (oldBatchId !== batchId) {
          updateBatchCandidateCounts(oldBatchId);
          updateBatchCandidateCounts(batchId);
        } else {
          updateBatchCandidateCounts(batchId);
        }
      }
      
      toast({
        title: 'Success',
        description: 'Candidate updated successfully',
      });
    }
    
    // Navigate back to batch detail or candidates list
    if (batchIdFromUrl) {
      setLocation(`/admin/batches/${batchIdFromUrl}`);
    } else {
      setLocation('/admin/candidates');
    }
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => batchIdFromUrl ? setLocation(`/admin/batches/${batchIdFromUrl}`) : setLocation('/admin/candidates')} 
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{isNewCandidate ? 'Add New Candidate' : 'Edit Candidate'}</h1>
            <p className="text-muted-foreground mt-1">
              {isNewCandidate ? 'Add a candidate to a batch' : 'Update candidate information'}
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Candidate Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input 
                  id="name" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Smith"
                  data-testid="input-candidate-name" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@example.com"
                  data-testid="input-candidate-email" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="technology">Technology</Label>
                <Input 
                  id="technology" 
                  value={technology}
                  onChange={(e) => setTechnology(e.target.value)}
                  placeholder=".NET Core, Dynamics 365, etc."
                  data-testid="input-candidate-technology" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="batch">Batch</Label>
                <Select value={batchId} onValueChange={setBatchId}>
                  <SelectTrigger data-testid="select-batch">
                    <SelectValue placeholder="Select batch" />
                  </SelectTrigger>
                  <SelectContent>
                    {batches.map(batch => (
                      <SelectItem key={batch.id} value={batch.id}>
                        {batch.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phase">Phase</Label>
                <Select value={phase} onValueChange={(value: any) => setPhase(value)}>
                  <SelectTrigger data-testid="select-phase">
                    <SelectValue placeholder="Select phase" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="mock_interviews">Mock Interviews</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="placed">Placed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="experience">Experience (years)</Label>
                <Input 
                  id="experience" 
                  type="number"
                  value={experience}
                  onChange={(e) => setExperience(Number(e.target.value))}
                  min="0"
                  data-testid="input-candidate-experience" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="progress">Progress (%)</Label>
                <Input 
                  id="progress" 
                  type="number"
                  value={progress}
                  onChange={(e) => setProgress(Number(e.target.value))}
                  min="0"
                  max="100"
                  data-testid="input-candidate-progress" 
                />
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={handleSave} data-testid="button-save">
                <Save className="mr-2 h-4 w-4" />
                {isNewCandidate ? 'Add Candidate' : 'Save Changes'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => batchIdFromUrl ? setLocation(`/admin/batches/${batchIdFromUrl}`) : setLocation('/admin/candidates')} 
                data-testid="button-cancel"
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
