import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import BatchCard from '@/components/BatchCard';
import { Button } from '@/components/ui/button';
import { getAllBatches } from '@/lib/data-service';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Plus } from 'lucide-react';
import { adminNavItems } from '@/lib/admin-nav';

const navItems = adminNavItems;

interface BatchesProps {
  onLogout?: () => void;
}

export default function Batches({ onLogout }: BatchesProps) {
  const [, setLocation] = useLocation();
  const [batches, setBatches] = useState(getAllBatches());
  const [batchToDelete, setBatchToDelete] = useState<string | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  useEffect(() => {
    const loadBatches = () => {
      setBatches(getAllBatches());
    };

    loadBatches();
    
    window.addEventListener('storage', loadBatches);
    window.addEventListener('focus', loadBatches);
    
    return () => {
      window.removeEventListener('storage', loadBatches);
      window.removeEventListener('focus', loadBatches);
    };
  }, []);

  const handleDeleteClick = (batchId: string) => {
    setBatchToDelete(batchId);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (batchToDelete) {
      // Remove batch from the batches array
      setBatches(prevBatches => prevBatches.filter(batch => batch.id !== batchToDelete));
      
      // Also remove from localStorage if it exists there
      const storedBatches = JSON.parse(localStorage.getItem('batches') || '[]');
      const updatedStoredBatches = storedBatches.filter((batch: any) => batch.id !== batchToDelete);
      localStorage.setItem('batches', JSON.stringify(updatedStoredBatches));
      
      // If it's an initial batch, mark it as deleted
      const deletedInitialBatches = JSON.parse(localStorage.getItem('deletedInitialBatches') || '[]');
      if (!deletedInitialBatches.includes(batchToDelete)) {
        deletedInitialBatches.push(batchToDelete);
        localStorage.setItem('deletedInitialBatches', JSON.stringify(deletedInitialBatches));
      }
    }
    setIsDeleteDialogOpen(false);
    setBatchToDelete(null);
  };

  const handleDeleteCancel = () => {
    setIsDeleteDialogOpen(false);
    setBatchToDelete(null);
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Batches</h1>
            <p className="text-muted-foreground mt-1">
              Manage and monitor training batches
            </p>
          </div>
          <Button onClick={() => setLocation('/admin/batches/new')} data-testid="button-add-batch">
            <Plus className="mr-2 h-4 w-4" />
            Add Batch
          </Button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {batches.map(batch => (
              <BatchCard
                key={batch.id}
                {...batch}
                onViewDetails={() => setLocation(`/admin/batches/${batch.id}`)}
                onDelete={() => handleDeleteClick(batch.id)}
              />
            ))}
          </div>
        </div>

        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete{' '}
                <span className="font-semibold">
                  {batchToDelete ? batches.find(b => b.id === batchToDelete)?.name : 'this batch'}
                </span>
                . This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={handleDeleteCancel}>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleDeleteConfirm}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
