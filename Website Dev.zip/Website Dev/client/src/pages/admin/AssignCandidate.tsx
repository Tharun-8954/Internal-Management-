import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  getUnassignedCandidates, 
  assignCandidateToBatch,
  getBatchById 
} from '@/lib/data-service';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  FileText,
  UserCheck,
  ArrowLeft,
  UserPlus,
  Mail,
  Briefcase
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Submissions', url: '/admin/submissions', icon: FileText },
  { title: 'Assignments', url: '/admin/assignments', icon: Briefcase },
];

interface AssignCandidateProps {
  onLogout?: () => void;
}

export default function AssignCandidate({ onLogout }: AssignCandidateProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const { toast } = useToast();
  
  const batchId = params.id || '';
  const batch = getBatchById(batchId);
  
  // Auto-set technology based on batch
  const batchTechnology = batch?.description || batch?.name || '';
  
  const [selectedUserId, setSelectedUserId] = useState('');
  const [technology, setTechnology] = useState(batchTechnology);
  const [phase, setPhase] = useState<'training' | 'mock_interviews' | 'marketing' | 'placed'>('training');
  const [experience, setExperience] = useState(0);
  
  const unassignedCandidates = getUnassignedCandidates();
  
  // Update technology when batch changes
  useEffect(() => {
    if (batch) {
      setTechnology(batch.description || batch.name);
    }
  }, [batch]);

  const handleAssign = () => {
    alert('Button clicked! Check console for details.');
    console.log('=== ASSIGN BUTTON CLICKED ===');
    console.log('Selected User ID:', selectedUserId);
    console.log('Batch ID:', batchId);
    console.log('Technology:', technology);
    console.log('Phase:', phase);
    console.log('Experience:', experience);
    
    if (!selectedUserId) {
      console.log('ERROR: No user selected');
      toast({
        title: 'Validation Error',
        description: 'Please select a candidate',
        variant: 'destructive',
      });
      return;
    }
    
    if (!technology.trim()) {
      console.log('ERROR: No technology entered');
      toast({
        title: 'Validation Error',
        description: 'Please enter technology',
        variant: 'destructive',
      });
      return;
    }

    console.log('Validation passed, calling assignCandidateToBatch...');
    
    try {
      assignCandidateToBatch(selectedUserId, batchId, technology, phase, experience);
      console.log('Assignment function completed');
      
      const assignments = localStorage.getItem('batchAssignments');
      console.log('Current batchAssignments in localStorage:', assignments);
      
      toast({
        title: 'Success',
        description: 'Candidate assigned to batch successfully',
      });
      
      console.log('Navigating back to batch detail...');
      setTimeout(() => {
        setLocation(`/admin/batches/${batchId}`);
      }, 1000);
    } catch (error) {
      console.error('ERROR during assignment:', error);
      toast({
        title: 'Error',
        description: 'Failed to assign candidate',
        variant: 'destructive',
      });
    }
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setLocation(`/admin/batches/${batchId}`)} 
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Assign Candidate to {batch?.name} Batch</h1>
            <p className="text-muted-foreground mt-1">
              Select a candidate user and set their details
            </p>
          </div>
        </div>

        {unassignedCandidates.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <UserCheck className="h-16 w-16 mx-auto mb-4 opacity-50 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No Available Candidates</h3>
              <p className="text-muted-foreground mb-4">
                All candidate users are already assigned to batches
              </p>
              <Button onClick={() => setLocation('/admin/users/new')} variant="outline">
                <Users className="mr-2 h-4 w-4" />
                Add New Candidate User
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Select Candidate</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {unassignedCandidates.map(candidate => (
                    <Card 
                      key={candidate.id}
                      className={`cursor-pointer transition-all ${
                        selectedUserId === candidate.id 
                          ? 'ring-2 ring-primary' 
                          : 'hover:shadow-md'
                      }`}
                      onClick={() => setSelectedUserId(candidate.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-semibold">{candidate.name}</h4>
                            <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                              <Mail className="h-3 w-3" />
                              {candidate.email}
                            </div>
                          </div>
                          {selectedUserId === candidate.id && (
                            <Badge>Selected</Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Assignment Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!selectedUserId && (
                  <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
                    <p className="text-sm text-yellow-800 dark:text-yellow-200">
                      ⚠️ Please select a candidate from the left panel first
                    </p>
                  </div>
                )}
                
                {selectedUserId && (
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md">
                    <p className="text-sm text-green-800 dark:text-green-200">
                      ✓ Candidate selected: {unassignedCandidates.find(c => c.id === selectedUserId)?.name}
                    </p>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="technology">Technology (Auto-filled from batch)</Label>
                  <Input 
                    id="technology" 
                    value={technology}
                    onChange={(e) => setTechnology(e.target.value)}
                    placeholder="Technology from batch"
                    disabled={!selectedUserId}
                    data-testid="input-technology"
                    className="bg-muted"
                  />
                  <p className="text-xs text-muted-foreground">
                    Technology is automatically set from the batch. You can edit if needed.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phase">Phase</Label>
                  <Select 
                    value={phase} 
                    onValueChange={(value: any) => setPhase(value)}
                    disabled={!selectedUserId}
                  >
                    <SelectTrigger data-testid="select-phase">
                      <SelectValue placeholder="Select phase" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="training">Training</SelectItem>
                      <SelectItem value="mock_interviews">Mock Interviews</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="placed">Placed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">Experience (years)</Label>
                  <Input 
                    id="experience" 
                    type="number"
                    value={experience}
                    onChange={(e) => setExperience(Number(e.target.value))}
                    min="0"
                    disabled={!selectedUserId}
                    data-testid="input-experience" 
                  />
                </div>

                <div className="p-3 bg-muted rounded-md">
                  <p className="text-sm text-muted-foreground">
                    <strong>Progress Calculation:</strong>
                  </p>
                  <ul className="text-sm text-muted-foreground mt-2 space-y-1">
                    <li>• Training: 25%</li>
                    <li>• Mock Interviews: 50%</li>
                    <li>• Marketing: 75%</li>
                    <li>• Placed: 100%</li>
                  </ul>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      handleAssign();
                    }} 
                    disabled={!selectedUserId}
                    data-testid="button-assign"
                  >
                    <UserPlus className="mr-2 h-4 w-4" />
                    Assign to Batch
                  </Button>
                  <Button 
                    type="button"
                    variant="outline" 
                    onClick={(e) => {
                      e.preventDefault();
                      setLocation(`/admin/batches/${batchId}`);
                    }} 
                    data-testid="button-cancel"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
