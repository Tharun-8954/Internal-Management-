import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { format } from 'date-fns';
import DashboardLayout from '@/components/DashboardLayout';
import SubmissionTable from '@/components/SubmissionTable';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { getInterviews } from '@/lib/data-service';
import { Search, CalendarIcon, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { adminNavItems } from '@/lib/admin-nav';

const navItems = adminNavItems;

interface InterviewsProps {
  onLogout?: () => void;
}

export default function Interviews({ onLogout }: InterviewsProps) {
  const [, setLocation] = useLocation();
  const [interviews, setInterviews] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCandidate, setFilterCandidate] = useState('all');
  const [filterCompany, setFilterCompany] = useState('all');
  const [filterSubmittedBy, setFilterSubmittedBy] = useState('all');
  const [sortBy, setSortBy] = useState<'date' | 'candidate' | 'company'>('date');
  const [dateMode, setDateMode] = useState<'single' | 'range'>('single');
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [dateFrom, setDateFrom] = useState<Date | undefined>();
  const [dateTo, setDateTo] = useState<Date | undefined>();

  useEffect(() => {
    loadInterviews();
    
    window.addEventListener('storage', loadInterviews);
    window.addEventListener('focus', loadInterviews);
    
    return () => {
      window.removeEventListener('storage', loadInterviews);
      window.removeEventListener('focus', loadInterviews);
    };
  }, []);

  const loadInterviews = () => {
    const allInterviews = getInterviews();
    setInterviews(allInterviews);
  };

  // Get unique values for filters
  const uniqueCandidates = Array.from(new Set(interviews.map(i => i.candidateName)));
  const uniqueCompanies = Array.from(new Set(interviews.map(i => i.company)));
  const uniqueSubmitters = Array.from(new Set(interviews.map(i => i.createdBy)));

  // Filter and sort interviews
  const filteredAndSortedInterviews = interviews
    .filter(interview => {
      const matchesSearch = 
        interview.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        interview.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        interview.createdBy.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCandidate = filterCandidate === 'all' || interview.candidateName === filterCandidate;
      const matchesCompany = filterCompany === 'all' || interview.company === filterCompany;
      const matchesSubmittedBy = filterSubmittedBy === 'all' || interview.createdBy === filterSubmittedBy;
      
      // Date filtering based on mode
      let matchesDate = true;
      const interviewDate = new Date(interview.submissionDate);
      
      if (dateMode === 'single' && selectedDate) {
        const selectedDateOnly = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate());
        const interviewDateOnly = new Date(interviewDate.getFullYear(), interviewDate.getMonth(), interviewDate.getDate());
        matchesDate = interviewDateOnly.getTime() === selectedDateOnly.getTime();
      } else if (dateMode === 'range') {
        const matchesDateFrom = !dateFrom || interviewDate >= dateFrom;
        const matchesDateTo = !dateTo || interviewDate <= dateTo;
        matchesDate = matchesDateFrom && matchesDateTo;
      }
      
      return matchesSearch && matchesCandidate && matchesCompany && matchesSubmittedBy && matchesDate;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'date':
          return new Date(b.submissionDate).getTime() - new Date(a.submissionDate).getTime();
        case 'candidate':
          return a.candidateName.localeCompare(b.candidateName);
        case 'company':
          return a.company.localeCompare(b.company);
        default:
          return 0;
      }
    });

  const clearFilters = () => {
    setSearchQuery('');
    setFilterCandidate('all');
    setFilterCompany('all');
    setFilterSubmittedBy('all');
    setDateMode('single');
    setSelectedDate(new Date());
    setDateFrom(undefined);
    setDateTo(undefined);
    setSortBy('date');
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="John Doe"
      userRole="Admin"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">🎥 Interviews</h1>
          <p className="text-muted-foreground mt-1">
            Track all candidate interviews
          </p>
        </div>

        {/* Search and Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by candidate, company, or submitted by..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Filters Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
                <Select value={filterCandidate} onValueChange={setFilterCandidate}>
                  <SelectTrigger>
                    <SelectValue placeholder="Candidate" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Candidates</SelectItem>
                    {uniqueCandidates.map(name => (
                      <SelectItem key={name} value={name}>{name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filterCompany} onValueChange={setFilterCompany}>
                  <SelectTrigger>
                    <SelectValue placeholder="Company" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Companies</SelectItem>
                    {uniqueCompanies.map(company => (
                      <SelectItem key={company} value={company}>{company}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filterSubmittedBy} onValueChange={setFilterSubmittedBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="Submitted By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Submitters</SelectItem>
                    {uniqueSubmitters.map(submitter => (
                      <SelectItem key={submitter} value={submitter}>{submitter}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={(v: any) => setSortBy(v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">Date (Newest)</SelectItem>
                    <SelectItem value="candidate">Candidate Name</SelectItem>
                    <SelectItem value="company">Company</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline" onClick={clearFilters} className="w-full">
                  <X className="mr-2 h-4 w-4" />
                  Clear
                </Button>
              </div>

              {/* Date Mode Toggle */}
              <div className="flex items-center gap-2">
                <Button
                  variant={dateMode === 'single' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDateMode('single')}
                >
                  Single Date
                </Button>
                <Button
                  variant={dateMode === 'range' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDateMode('range')}
                >
                  Date Range
                </Button>
              </div>

              {/* Date Picker - Single or Range */}
              {dateMode === 'single' ? (
                <div className="flex items-center gap-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "justify-start text-left font-normal",
                          !selectedDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {selectedDate ? format(selectedDate, 'PPP') : 'Select date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedDate(new Date())}
                  >
                    Today
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "justify-start text-left font-normal",
                          !dateFrom && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateFrom ? format(dateFrom, 'PPP') : 'From date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={dateFrom}
                        onSelect={setDateFrom}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>

                  <span className="text-muted-foreground">to</span>

                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "justify-start text-left font-normal",
                          !dateTo && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateTo ? format(dateTo, 'PPP') : 'To date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={dateTo}
                        onSelect={setDateTo}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              )}

              {/* Results Count */}
              <div className="text-sm text-muted-foreground">
                Showing {filteredAndSortedInterviews.length} of {interviews.length} interviews
              </div>
            </div>
          </CardContent>
        </Card>

        <SubmissionTable
          submissions={filteredAndSortedInterviews}
          onViewDetails={(id) => setLocation(`/admin/submissions/${id}`)}
          showSubmittedBy={true}
        />
      </div>
    </DashboardLayout>
  );
}
