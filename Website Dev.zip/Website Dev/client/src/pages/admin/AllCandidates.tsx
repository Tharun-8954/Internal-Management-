import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getCandidateUsers, getBatchAssignments, getAllBatches, getProgressFromPhase } from '@/lib/data-service';
import { Search, Mail } from 'lucide-react';
import { adminNavItems } from '@/lib/admin-nav';

const navItems = adminNavItems;

interface AllCandidatesProps {
  onLogout?: () => void;
}

export default function AllCandidates({ onLogout }: AllCandidatesProps) {
  const [, setLocation] = useLocation();
  const [candidateUsers, setCandidateUsers] = useState(getCandidateUsers());
  const [assignments, setAssignments] = useState(getBatchAssignments());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBatch, setFilterBatch] = useState('all');
  const [filterPhase, setFilterPhase] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const batches = getAllBatches();

  useEffect(() => {
    const loadData = () => {
      setCandidateUsers(getCandidateUsers());
      setAssignments(getBatchAssignments());
    };

    loadData();
    
    window.addEventListener('storage', loadData);
    window.addEventListener('focus', loadData);
    
    return () => {
      window.removeEventListener('storage', loadData);
      window.removeEventListener('focus', loadData);
    };
  }, []);

  const filteredAndSortedCandidates = candidateUsers
    .filter(candidate => {
      const query = searchQuery.toLowerCase();
      const assignment = assignments.find(a => a.userId === candidate.id);
      const batch = assignment ? batches.find(b => b.id === assignment.batchId) : null;
      
      // Search filter
      const matchesSearch = (
        candidate.name.toLowerCase().includes(query) ||
        candidate.email.toLowerCase().includes(query) ||
        batch?.name.toLowerCase().includes(query) ||
        assignment?.technology.toLowerCase().includes(query)
      );
      
      // Batch filter
      const matchesBatch = filterBatch === 'all' || 
        (filterBatch === 'unassigned' && !assignment) ||
        (assignment && assignment.batchId === filterBatch);
      
      // Phase filter
      const matchesPhase = filterPhase === 'all' || 
        (assignment && assignment.phase === filterPhase);
      
      return matchesSearch && matchesBatch && matchesPhase;
    })
    .sort((a, b) => {
      const assignmentA = assignments.find(asn => asn.userId === a.id);
      const assignmentB = assignments.find(asn => asn.userId === b.id);
      const batchA = assignmentA ? batches.find(b => b.id === assignmentA.batchId) : null;
      const batchB = assignmentB ? batches.find(b => b.id === assignmentB.batchId) : null;
      
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'email':
          return a.email.localeCompare(b.email);
        case 'batch':
          return (batchA?.name || 'ZZZ').localeCompare(batchB?.name || 'ZZZ');
        case 'phase':
          return (assignmentA?.phase || 'zzz').localeCompare(assignmentB?.phase || 'zzz');
        default:
          return 0;
      }
    });

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">All Candidates</h1>
            <p className="text-muted-foreground mt-1">
              View and manage all candidates across batches
            </p>
          </div>
          <Button onClick={() => setLocation('/admin/users/new')} data-testid="button-add-candidate">
            <UserCheck className="mr-2 h-4 w-4" />
            Add Candidate User
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search candidates..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-candidates"
            />
          </div>
          <Select value={filterBatch} onValueChange={setFilterBatch}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by batch" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Batches</SelectItem>
              {batches.map(batch => (
                <SelectItem key={batch.id} value={batch.id}>{batch.name}</SelectItem>
              ))}
              <SelectItem value="unassigned">Unassigned</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterPhase} onValueChange={setFilterPhase}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by phase" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Phases</SelectItem>
              <SelectItem value="training">Training</SelectItem>
              <SelectItem value="mock_interviews">Mock Interviews</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
              <SelectItem value="placed">Placed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="batch">Batch</SelectItem>
              <SelectItem value="phase">Phase</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {filteredAndSortedCandidates.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <UserCheck className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No candidate users found</p>
              <p className="text-sm mt-1">Add users with "Candidate" role in User Management</p>
              <Button 
                onClick={() => setLocation('/admin/users/new')} 
                className="mt-4"
                variant="outline"
              >
                <UserCheck className="mr-2 h-4 w-4" />
                Add Candidate User
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAndSortedCandidates.map(candidate => {
                const assignment = assignments.find(a => a.userId === candidate.id);
                const batch = assignment ? batches.find(b => b.id === assignment.batchId) : null;
                
                return (
                  <Card key={candidate.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setLocation(`/admin/users/${candidate.id}`)}>
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-lg">{candidate.name}</h3>
                            <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                              <Mail className="h-3 w-3" />
                              {candidate.email}
                            </div>
                          </div>
                          <Badge variant={candidate.status === 'active' ? 'default' : 'secondary'}>
                            {candidate.status}
                          </Badge>
                        </div>
                        
                        {assignment && batch ? (
                          <div className="space-y-2 pt-2 border-t">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Batch:</span>
                              <span className="font-medium">{batch.name}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Technology:</span>
                              <span className="font-medium">{assignment.technology}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Phase:</span>
                              <Badge variant="outline" className="text-xs">
                                {assignment.phase.replace('_', ' ')}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Progress:</span>
                              <span className="font-medium">{getProgressFromPhase(assignment.phase)}%</span>
                            </div>
                          </div>
                        ) : (
                          <div className="pt-2 border-t">
                            <Badge variant="secondary" className="text-xs">
                              Not assigned to batch
                            </Badge>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
