import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import CandidateCard from '@/components/CandidateCard';
import { useToast } from '@/hooks/use-toast';
import { getBatchById, initialMockBatches, getCandidatesByBatch, updateBatchCandidateCounts, removeCandidateFromBatch, assignCandidateToBatch, getBatchAssignments } from '@/lib/data-service';
import { ArrowLeft, UserPlus, Save, Edit } from 'lucide-react';
import { adminNavItems } from '@/lib/admin-nav';

const navItems = adminNavItems;

interface BatchDetailProps {
  onLogout?: () => void;
}

export default function BatchDetail({ onLogout }: BatchDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const { toast } = useToast();
  
  const isNewBatch = params.id === 'new';
  const [isEditing, setIsEditing] = useState(isNewBatch);
  const [candidates, setCandidates] = useState<any[]>([]);
  const [isPhaseDialogOpen, setIsPhaseDialogOpen] = useState(false);
  const [selectedCandidateId, setSelectedCandidateId] = useState('');
  const [newPhase, setNewPhase] = useState('');
  
  // Form state
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [durationMonths, setDurationMonths] = useState(6);
  const [isActive, setIsActive] = useState(true);

  // Load batch data and candidates
  useEffect(() => {
    if (isNewBatch) {
      setName('');
      setDescription('');
      setStartDate('');
      setDurationMonths(6);
      setIsActive(true);
      setCandidates([]);
    } else {
      const batch = getBatchById(params.id || '');
      if (batch) {
        setName(batch.name);
        setDescription(batch.description);
        setStartDate(batch.startDate || '');
        setDurationMonths(batch.durationMonths || 6);
        setIsActive(batch.isActive);
      }
      
      // Load candidates for this batch
      const batchCandidates = getCandidatesByBatch(params.id || '');
      setCandidates(batchCandidates);
    }
  }, [params.id, isNewBatch]);

  // Reload candidates when returning to page
  useEffect(() => {
    if (!isNewBatch) {
      const loadCandidates = () => {
        const batchCandidates = getCandidatesByBatch(params.id || '');
        setCandidates(batchCandidates);
      };
      
      window.addEventListener('focus', loadCandidates);
      return () => window.removeEventListener('focus', loadCandidates);
    }
  }, [params.id, isNewBatch]);

  const handleSave = () => {
    if (!name.trim() || !description.trim() || !startDate) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const batchId = isNewBatch ? Date.now().toString() : params.id;
    
    const updatedBatch = {
      id: batchId,
      name,
      description,
      startDate,
      durationMonths,
      totalCandidates: 0,
      trainingCount: 0,
      mockInterviewCount: 0,
      marketingCount: 0,
      placedCount: 0,
      isActive,
    };

    const storedBatches = JSON.parse(localStorage.getItem('batches') || '[]');
    
    if (isNewBatch) {
      storedBatches.push(updatedBatch);
      localStorage.setItem('batches', JSON.stringify(storedBatches));
      
      toast({
        title: 'Success',
        description: 'Batch created successfully',
      });
      setLocation('/admin/batches');
    } else {
      const batchIndex = storedBatches.findIndex((b: any) => b.id === params.id);
      const isInitialBatch = initialMockBatches.some(b => b.id === params.id);
      
      if (batchIndex >= 0) {
        storedBatches[batchIndex] = { 
          ...storedBatches[batchIndex], 
          name, 
          description, 
          startDate, 
          durationMonths, 
          isActive 
        };
        localStorage.setItem('batches', JSON.stringify(storedBatches));
      } else if (isInitialBatch) {
        storedBatches.push(updatedBatch);
        localStorage.setItem('batches', JSON.stringify(storedBatches));
        
        const modifiedInitialBatches = JSON.parse(localStorage.getItem('modifiedInitialBatches') || '[]');
        if (!modifiedInitialBatches.includes(params.id)) {
          modifiedInitialBatches.push(params.id);
          localStorage.setItem('modifiedInitialBatches', JSON.stringify(modifiedInitialBatches));
        }
      }
      
      toast({
        title: 'Success',
        description: 'Batch updated successfully',
      });
      setIsEditing(false);
    }
  };

  const handleUnassign = (candidateId: string, candidateName: string) => {
    if (confirm(`Are you sure you want to unassign ${candidateName} from this batch?`)) {
      removeCandidateFromBatch(candidateId);
      
      toast({
        title: 'Success',
        description: `${candidateName} has been unassigned from the batch`,
      });
      
      // Reload candidates
      const batchCandidates = getCandidatesByBatch(params.id || '');
      setCandidates(batchCandidates);
    }
  };

  const handlePhaseChange = (candidateId: string) => {
    const candidate = candidates.find(c => c.id === candidateId);
    if (candidate) {
      setSelectedCandidateId(candidateId);
      setNewPhase(candidate.phase);
      setIsPhaseDialogOpen(true);
    }
  };

  const handlePhaseUpdate = () => {
    if (!selectedCandidateId || !newPhase) return;
    
    const candidate = candidates.find(c => c.id === selectedCandidateId);
    if (!candidate) return;
    
    const batchAssignments = getBatchAssignments();
    const assignment = batchAssignments.find(a => a.userId === selectedCandidateId);
    
    if (assignment) {
      assignCandidateToBatch(
        selectedCandidateId,
        params.id || '',
        assignment.technology,
        newPhase as any,
        assignment.experience
      );
      
      toast({
        title: 'Success',
        description: `Phase updated to ${newPhase.replace('_', ' ')}`,
      });
      
      // Reload candidates
      const batchCandidates = getCandidatesByBatch(params.id || '');
      setCandidates(batchCandidates);
      
      setIsPhaseDialogOpen(false);
      setSelectedCandidateId('');
      setNewPhase('');
    }
  };
  
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/admin/batches')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">{isNewBatch ? 'Create New Batch' : `${name} Batch`}</h1>
            <p className="text-muted-foreground mt-1">
              {isNewBatch ? 'Add a new training batch' : description}
            </p>
          </div>
          {!isNewBatch && (
            <div className="flex gap-2">
              <Button onClick={() => setLocation(`/admin/batches/${params.id}/assign`)} data-testid="button-add-candidate">
                <UserPlus className="mr-2 h-4 w-4" />
                Assign Candidate
              </Button>
              {!isEditing && (
                <Button onClick={() => setIsEditing(true)} data-testid="button-edit">
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              )}
            </div>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Batch Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Batch Name</Label>
                <Input 
                  id="name" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-batch-name" 
                />
              </div>
              <div className="space-y-2 flex items-end">
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="isActive" 
                    checked={isActive}
                    onCheckedChange={setIsActive}
                    disabled={!isEditing}
                  />
                  <Label htmlFor="isActive">Active Batch</Label>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea 
                id="description" 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                disabled={!isEditing}
                data-testid="input-batch-description" 
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date</Label>
                <Input 
                  id="startDate" 
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-start-date" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="durationMonths">Duration (months)</Label>
                <Input 
                  id="durationMonths" 
                  type="number"
                  value={durationMonths}
                  onChange={(e) => setDurationMonths(Number(e.target.value))}
                  min="1"
                  disabled={!isEditing}
                  data-testid="input-duration-months" 
                />
              </div>
            </div>

            {isEditing && (
              <div className="flex gap-2 pt-4">
                <Button onClick={handleSave} data-testid="button-save">
                  <Save className="mr-2 h-4 w-4" />
                  {isNewBatch ? 'Create Batch' : 'Save Changes'}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    if (isNewBatch) {
                      setLocation('/admin/batches');
                    } else {
                      setIsEditing(false);
                      // Reload data
                      const batch = getBatchById(params.id || '');
                      if (batch) {
                        setName(batch.name);
                        setDescription(batch.description);
                        setStartDate(batch.startDate || '');
                        setDurationMonths(batch.durationMonths || 6);
                        setIsActive(batch.isActive);
                      }
                    }
                  }} 
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {!isNewBatch && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Candidates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{candidates.length}</div>
                  <p className="text-xs text-muted-foreground mt-1">Active in batch</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">In Training</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {candidates.filter(c => c.phase === 'training').length}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Mock Interviews</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                    {candidates.filter(c => c.phase === 'mock_interviews').length}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Placed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {candidates.filter(c => c.phase === 'placed').length}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Batch Candidates ({candidates.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {candidates.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No candidates assigned to this batch yet</p>
                    <Button 
                      onClick={() => setLocation(`/admin/batches/${params.id}/assign`)} 
                      className="mt-4"
                      variant="outline"
                    >
                      <UserPlus className="mr-2 h-4 w-4" />
                      Assign First Candidate
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {candidates.map(candidate => (
                      <div key={candidate.id} className="relative group">
                        <CandidateCard
                          {...candidate}
                          batch={name as any}
                          onClick={() => setLocation(`/admin/users/${candidate.id}`)}
                        />
                        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePhaseChange(candidate.id);
                            }}
                            data-testid={`button-change-phase-${candidate.id}`}
                          >
                            Change Phase
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUnassign(candidate.id, candidate.name);
                            }}
                            data-testid={`button-unassign-${candidate.id}`}
                          >
                            Unassign
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Dialog open={isPhaseDialogOpen} onOpenChange={setIsPhaseDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Candidate Phase</DialogTitle>
            <DialogDescription>
              Update the training phase for this candidate
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>New Phase</Label>
              <Select value={newPhase} onValueChange={setNewPhase}>
                <SelectTrigger>
                  <SelectValue placeholder="Select phase" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="training">Training</SelectItem>
                  <SelectItem value="mock_interviews">Mock Interviews</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="placed">Placed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPhaseDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePhaseUpdate}>
              Update Phase
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
