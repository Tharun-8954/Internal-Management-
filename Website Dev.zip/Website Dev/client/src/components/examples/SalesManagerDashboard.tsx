import SalesManagerDashboard from '../../pages/SalesManagerDashboard';

export default function SalesManagerDashboardExample() {
  return <SalesManagerDashboard />;
}
