import CandidateProfile from '../../pages/CandidateProfile';

export default function CandidateProfileExample() {
  return <CandidateProfile />;
}
