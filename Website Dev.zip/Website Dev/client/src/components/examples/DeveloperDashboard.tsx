import DeveloperDashboard from '../../pages/DeveloperDashboard';

export default function DeveloperDashboardExample() {
  return <DeveloperDashboard />;
}
