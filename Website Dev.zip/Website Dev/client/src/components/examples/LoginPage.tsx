import LoginPage from '../LoginPage';

export default function LoginPageExample() {
  return <LoginPage onLogin={(email, role) => console.log('Logged in:', email, role)} />;
}
