import BatchCard from '../BatchCard';

export default function BatchCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      <BatchCard
        id="1"
        name="Net"
        description="Microsoft .NET Technologies"
        totalCandidates={28}
        trainingCount={12}
        mockInterviewCount={8}
        marketingCount={6}
        placedCount={2}
        isActive={true}
        onViewDetails={() => console.log('View Net batch details')}
      />
      <BatchCard
        id="2"
        name="Dynamics"
        description="Microsoft Dynamics 365"
        totalCandidates={17}
        trainingCount={5}
        mockInterviewCount={7}
        marketingCount={3}
        placedCount={2}
        isActive={true}
        onViewDetails={() => console.log('View Dynamics batch details')}
      />
    </div>
  );
}
