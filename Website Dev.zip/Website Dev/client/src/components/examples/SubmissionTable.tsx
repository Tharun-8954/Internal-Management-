import SubmissionTable from '../SubmissionTable';

const mockSubmissions = [
  { id: '1', candidateName: 'John Smith', company: 'Tech Corp', submissionDate: '2024-01-15', rate: '$85/hr', status: 'interview' as const },
  { id: '2', candidateName: 'Sarah Johnson', company: 'Global Industries', submissionDate: '2024-01-14', rate: '$90/hr', status: 'offer' as const },
  { id: '3', candidateName: 'Mike Brown', company: 'StartUp Inc', submissionDate: '2024-01-13', rate: '$75/hr', status: 'assessment' as const },
];

export default function SubmissionTableExample() {
  return (
    <div className="p-6">
      <SubmissionTable
        submissions={mockSubmissions}
        onViewDetails={(id) => console.log('View submission:', id)}
      />
    </div>
  );
}
