import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  Calendar,
  Star,
  BookOpen,
  MessageSquare
} from 'lucide-react';

const navItems = [
  { title: 'My Profile', url: '/candidate/dashboard', icon: User },
  { title: 'My Progress', url: '/candidate/progress', icon: Briefcase },
  { title: 'Mock Interviews', url: '/candidate/interviews', icon: MessageSquare },
  { title: 'Resources', url: '/candidate/resources', icon: BookOpen },
];

const candidateData = {
  name: 'Alice Williams',
  email: 'alice.williams@email.com',
  phone: '+1 (555) 123-4567',
  location: 'New York, NY',
  technology: '.NET Core',
  experience: 3,
  batch: 'Net',
  phase: 'marketing',
  progress: 85,
  trainingStartDate: '2024-09-01',
  trainingEndDate: '2024-11-30',
  skills: ['.NET Core', 'C#', 'ASP.NET', 'Entity Framework', 'SQL Server', 'Azure'],
};

const mockInterviews = [
  { id: 1, date: '2024-12-15', interviewer: 'John Doe', rating: 4, feedback: 'Strong technical skills, needs improvement in communication' },
  { id: 2, date: '2024-12-20', interviewer: 'Jane Smith', rating: 5, feedback: 'Excellent performance, ready for client interviews' },
];

interface CandidateProfileProps {
  onLogout?: () => void;
}

export default function CandidateProfile({ onLogout }: CandidateProfileProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName={candidateData.name}
      userRole="Candidate"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Profile</h1>
          <p className="text-muted-foreground mt-1">View your information and track your progress</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src="" alt={candidateData.name} />
                    <AvatarFallback className="text-2xl">AW</AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-semibold">{candidateData.name}</h2>
                  <p className="text-sm text-muted-foreground">{candidateData.technology} Developer</p>
                  <Badge variant="outline" className="mt-2 bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border-cyan-500/20">
                    {candidateData.batch} Batch
                  </Badge>
                </div>

                <Separator />

                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Email</p>
                      <p className="text-sm">{candidateData.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Phone</p>
                      <p className="text-sm">{candidateData.phone}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Location</p>
                      <p className="text-sm">{candidateData.location}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Briefcase className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Experience</p>
                      <p className="text-sm">{candidateData.experience} years</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Current Phase: Marketing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Overall Progress</span>
                    <span className="text-sm text-muted-foreground">{candidateData.progress}%</span>
                  </div>
                  <Progress value={candidateData.progress} className="h-2" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                  <div className="text-center p-4 bg-green-500/10 rounded-md border border-green-500/20">
                    <p className="text-xs text-muted-foreground mb-1">Phase 1</p>
                    <p className="font-semibold">Training</p>
                    <Badge variant="outline" className="mt-2 bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
                      Completed
                    </Badge>
                  </div>
                  <div className="text-center p-4 bg-green-500/10 rounded-md border border-green-500/20">
                    <p className="text-xs text-muted-foreground mb-1">Phase 2</p>
                    <p className="font-semibold">Mock Interviews</p>
                    <Badge variant="outline" className="mt-2 bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
                      Completed
                    </Badge>
                  </div>
                  <div className="text-center p-4 bg-purple-500/10 rounded-md border-2 border-purple-500">
                    <p className="text-xs text-muted-foreground mb-1">Phase 3</p>
                    <p className="font-semibold">Marketing</p>
                    <Badge className="mt-2 bg-purple-500 text-white">
                      In Progress
                    </Badge>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button onClick={() => setLocation('/candidate/progress')} className="w-full" data-testid="button-view-detailed-progress">
                    View Detailed Progress
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Training Period</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-start gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Start Date</p>
                      <p className="text-sm font-medium">{candidateData.trainingStartDate}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">End Date</p>
                      <p className="text-sm font-medium">{candidateData.trainingEndDate}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Technical Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {candidateData.skills.map((skill) => (
                    <Badge key={skill} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Mock Interview Feedback</CardTitle>
                <Button variant="outline" size="sm" onClick={() => setLocation('/candidate/interviews')} data-testid="button-view-all-interviews">
                  View All
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockInterviews.map((interview) => (
                  <div key={interview.id} className="p-4 border rounded-md space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">{interview.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: interview.rating }).map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">Interviewer: {interview.interviewer}</p>
                    <p className="text-sm">{interview.feedback}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
