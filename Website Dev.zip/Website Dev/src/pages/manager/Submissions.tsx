import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import SubmissionTable from '@/components/SubmissionTable';
import { Input } from '@/components/ui/input';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  Search
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

const mockSubmissions = [
  { id: '1', candidateName: 'John Smith', company: 'Tech Corp', submissionDate: '2024-01-15', rate: '$85/hr', status: 'interview' as const },
  { id: '2', candidateName: 'Sarah Johnson', company: 'Global Industries', submissionDate: '2024-01-14', rate: '$90/hr', status: 'offer' as const },
  { id: '3', candidateName: 'Mike Brown', company: 'Innovation Labs', submissionDate: '2024-01-12', rate: '$80/hr', status: 'assessment' as const },
  { id: '4', candidateName: 'Emily Davis', company: 'Tech Solutions', submissionDate: '2024-01-10', rate: '$75/hr', status: 'initial_screening' as const },
];

interface SubmissionsProps {
  onLogout?: () => void;
}

export default function Submissions({ onLogout }: SubmissionsProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Submissions</h1>
          <p className="text-muted-foreground mt-1">
            Track all candidate submissions and their status
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search submissions..."
              className="pl-10"
              data-testid="input-search-submissions"
            />
          </div>
        </div>

        <SubmissionTable
          submissions={mockSubmissions}
          onViewDetails={(id) => setLocation(`/manager/submissions?id=${id}`)}
        />
      </div>
    </DashboardLayout>
  );
}
