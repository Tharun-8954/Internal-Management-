import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import CandidateCard from '@/components/CandidateCard';
import { Progress } from '@/components/ui/progress';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  ArrowLeft
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

const mockCandidates = [
  { id: '1', name: 'John Smith', technology: '.NET Core', batch: 'Net' as const, phase: 'training' as const, experience: 3, progress: 65 },
  { id: '2', name: 'Mike Brown', technology: 'ASP.NET', batch: 'Net' as const, phase: 'mock_interviews' as const, experience: 4, progress: 75 },
  { id: '3', name: 'Emily Davis', technology: 'C#', batch: 'Net' as const, phase: 'marketing' as const, experience: 2, progress: 85 },
];

interface BatchDetailProps {
  onLogout?: () => void;
}

export default function BatchDetail({ onLogout }: BatchDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();
  const batchName = params.id === '1' ? 'Net' : 'Dynamics';
  
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/manager/batches')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">{batchName} Batch</h1>
            <p className="text-muted-foreground mt-1">
              Microsoft {batchName === 'Net' ? '.NET Technologies' : 'Dynamics 365'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Candidates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">28</div>
              <p className="text-xs text-muted-foreground mt-1">Active in batch</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Training</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">12</div>
              <Progress value={43} className="h-1.5 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Mock Interviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">8</div>
              <Progress value={29} className="h-1.5 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Placed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">2</div>
              <Progress value={7} className="h-1.5 mt-2" />
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Batch Candidates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockCandidates.map(candidate => (
                <CandidateCard
                  key={candidate.id}
                  {...candidate}
                  onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
