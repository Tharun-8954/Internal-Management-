import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import BatchCard from '@/components/BatchCard';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface BatchesProps {
  onLogout?: () => void;
}

export default function Batches({ onLogout }: BatchesProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Training Batches</h1>
          <p className="text-muted-foreground mt-1">
            View all training batches and their progress
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <BatchCard
            id="1"
            name="Net"
            description="Microsoft .NET Technologies"
            totalCandidates={28}
            trainingCount={12}
            mockInterviewCount={8}
            marketingCount={6}
            placedCount={2}
            isActive={true}
            onViewDetails={() => setLocation('/manager/batches/1')}
          />
          <BatchCard
            id="2"
            name="Dynamics"
            description="Microsoft Dynamics 365"
            totalCandidates={17}
            trainingCount={5}
            mockInterviewCount={7}
            marketingCount={3}
            placedCount={2}
            isActive={true}
            onViewDetails={() => setLocation('/manager/batches/2')}
          />
        </div>
      </div>
    </DashboardLayout>
  );
}
