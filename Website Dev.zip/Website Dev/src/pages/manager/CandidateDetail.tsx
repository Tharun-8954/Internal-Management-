import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  ArrowLeft,
  Mail,
  Phone,
  Briefcase,
  Send
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

interface CandidateDetailProps {
  onLogout?: () => void;
}

export default function CandidateDetail({ onLogout }: CandidateDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/manager/dashboard')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Candidate Details</h1>
            <p className="text-muted-foreground mt-1">View candidate information and progress</p>
          </div>
          <Button onClick={() => setLocation('/manager/submissions?candidate=' + params.id)} data-testid="button-submit-candidate">
            <Send className="mr-2 h-4 w-4" />
            Create Submission
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Profile</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src="" alt="John Smith" />
                  <AvatarFallback className="text-2xl">JS</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-semibold">John Smith</h2>
                <p className="text-sm text-muted-foreground">.NET Core Developer</p>
                <Badge variant="outline" className="mt-2 bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border-cyan-500/20">
                  Net Batch
                </Badge>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm">john.smith@email.com</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Phone className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="text-sm">+1 (555) 123-4567</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Briefcase className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">Experience</p>
                    <p className="text-sm">3 years</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Progress & Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Overall Progress</span>
                  <span className="text-sm text-muted-foreground">65%</span>
                </div>
                <Progress value={65} className="h-2" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-500/10 rounded-md border border-green-500/20">
                  <p className="text-xs text-muted-foreground mb-1">Phase</p>
                  <p className="font-semibold">Training</p>
                  <Badge variant="outline" className="mt-2 bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20">
                    In Progress
                  </Badge>
                </div>
                <div className="text-center p-4 border rounded-md">
                  <p className="text-xs text-muted-foreground mb-1">Assigned To</p>
                  <p className="font-semibold">Bob Johnson</p>
                  <p className="text-xs text-muted-foreground mt-1">Sales Employee</p>
                </div>
                <div className="text-center p-4 border rounded-md">
                  <p className="text-xs text-muted-foreground mb-1">Submissions</p>
                  <p className="text-3xl font-bold">0</p>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {['.NET Core', 'C#', 'ASP.NET', 'Entity Framework', 'SQL Server'].map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
