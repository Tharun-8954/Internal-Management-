import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import CandidateCard from '@/components/CandidateCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  UserCog
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

const mockUnassignedCandidates = [
  { id: '1', name: 'John Smith', technology: '.NET Core', batch: 'Net' as const, phase: 'training' as const, experience: 3, progress: 65 },
  { id: '2', name: 'Emily Davis', technology: 'C#', batch: 'Net' as const, phase: 'training' as const, experience: 2, progress: 50 },
];

const mockAssignedCandidates = [
  { id: '3', name: 'Sarah Johnson', technology: 'Dynamics 365', batch: 'Dynamics' as const, phase: 'marketing' as const, experience: 5, progress: 90, assignedTo: 'Bob Johnson' },
  { id: '4', name: 'Mike Brown', technology: 'ASP.NET', batch: 'Net' as const, phase: 'mock_interviews' as const, experience: 4, progress: 75, assignedTo: 'Sarah Williams' },
];

interface AssignmentsProps {
  onLogout?: () => void;
}

export default function Assignments({ onLogout }: AssignmentsProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Candidate Assignments</h1>
          <p className="text-muted-foreground mt-1">
            Assign candidates to your sales team members
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Unassigned Candidates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockUnassignedCandidates.map(candidate => (
                <div key={candidate.id} className="relative">
                  <CandidateCard
                    {...candidate}
                    onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                  />
                  <Button
                    size="sm"
                    className="absolute top-2 right-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/manager/assignments?assign=${candidate.id}`);
                    }}
                    data-testid={`button-assign-${candidate.id}`}
                  >
                    <UserCog className="mr-1 h-3 w-3" />
                    Assign
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Currently Assigned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockAssignedCandidates.map(candidate => (
                <div key={candidate.id} className="space-y-2">
                  <CandidateCard
                    id={candidate.id}
                    name={candidate.name}
                    technology={candidate.technology}
                    batch={candidate.batch}
                    phase={candidate.phase}
                    experience={candidate.experience}
                    progress={candidate.progress}
                    onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                  />
                  <div className="flex items-center justify-between px-1">
                    <Badge variant="outline" className="text-xs">
                      {candidate.assignedTo}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setLocation(`/manager/assignments?reassign=${candidate.id}`)}
                      data-testid={`button-reassign-${candidate.id}`}
                    >
                      Reassign
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
