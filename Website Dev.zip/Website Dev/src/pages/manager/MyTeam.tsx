import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

const mockTeamMembers = [
  { id: '1', name: 'Bob Johnson', email: 'bob@saggisolutions.com', assignedCandidates: 8, placements: 3, performance: 85 },
  { id: '2', name: 'Sarah Williams', email: 'sarah@saggisolutions.com', assignedCandidates: 6, placements: 4, performance: 92 },
  { id: '3', name: 'Tom Davis', email: 'tom@saggisolutions.com', assignedCandidates: 7, placements: 2, performance: 78 },
];

interface MyTeamProps {
  onLogout?: () => void;
}

export default function MyTeam({ onLogout }: MyTeamProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Team</h1>
          <p className="text-muted-foreground mt-1">
            Manage and monitor your sales team performance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {mockTeamMembers.map((member) => (
            <Card key={member.id} className="hover-elevate cursor-pointer" onClick={() => setLocation(`/manager/team/${member.id}`)} data-testid={`card-team-member-${member.id}`}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src="" alt={member.name} />
                    <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-base">{member.name}</CardTitle>
                    <p className="text-xs text-muted-foreground">{member.email}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Assigned</p>
                    <p className="text-xl font-bold">{member.assignedCandidates}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Placements</p>
                    <p className="text-xl font-bold text-green-600 dark:text-green-400">{member.placements}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Performance</span>
                    <Badge variant="outline" className={member.performance >= 90 ? 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20' : member.performance >= 80 ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20' : 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20'}>
                      {member.performance}%
                    </Badge>
                  </div>
                  <Progress value={member.performance} className="h-2" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
