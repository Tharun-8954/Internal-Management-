import { useLocation, useParams } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  ArrowLeft,
  Building2,
  DollarSign,
  Calendar,
  User
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

interface SubmissionDetailProps {
  onLogout?: () => void;
}

export default function SubmissionDetail({ onLogout }: SubmissionDetailProps) {
  const [, setLocation] = useLocation();
  const params = useParams();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/sales/submissions')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Submission Details</h1>
            <p className="text-muted-foreground mt-1">Submission ID: {params.id}</p>
          </div>
          <Badge variant="outline" className="bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/20">
            Interview
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Submission Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Candidate</p>
                  <p className="text-sm font-medium">John Smith</p>
                  <p className="text-xs text-muted-foreground">.NET Core Developer</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <Building2 className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Company</p>
                  <p className="text-sm font-medium">Tech Corp</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <DollarSign className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Hourly Rate</p>
                  <p className="text-sm font-medium">$85/hr</p>
                </div>
              </div>

              <Separator />

              <div className="flex items-start gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Submission Date</p>
                  <p className="text-sm font-medium">2024-01-15</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status Timeline</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-2 w-2 rounded-full bg-green-500" />
                  <div className="h-full w-px bg-green-500/30" />
                </div>
                <div className="flex-1 pb-4">
                  <p className="text-sm font-medium">Submitted</p>
                  <p className="text-xs text-muted-foreground">Jan 15, 2024</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-2 w-2 rounded-full bg-green-500" />
                  <div className="h-full w-px bg-green-500/30" />
                </div>
                <div className="flex-1 pb-4">
                  <p className="text-sm font-medium">Initial Screening</p>
                  <p className="text-xs text-muted-foreground">Jan 16, 2024</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-2 w-2 rounded-full bg-purple-500" />
                  <div className="h-full w-px bg-gray-300 dark:bg-gray-700" />
                </div>
                <div className="flex-1 pb-4">
                  <p className="text-sm font-medium">Interview Scheduled</p>
                  <p className="text-xs text-muted-foreground">Jan 18, 2024</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-2 w-2 rounded-full bg-gray-300 dark:bg-gray-700" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">Pending Next Steps</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
