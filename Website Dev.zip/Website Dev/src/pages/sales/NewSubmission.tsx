import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  ArrowLeft,
  Send
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

interface NewSubmissionProps {
  onLogout?: () => void;
}

export default function NewSubmission({ onLogout }: NewSubmissionProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation('/sales/dashboard')} data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">New Submission</h1>
            <p className="text-muted-foreground mt-1">
              Submit a candidate to a client company
            </p>
          </div>
        </div>

        <Card className="max-w-3xl">
          <CardHeader>
            <CardTitle>Submission Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="candidate">Candidate</Label>
              <Select>
                <SelectTrigger data-testid="select-candidate">
                  <SelectValue placeholder="Select candidate" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">John Smith (.NET Core)</SelectItem>
                  <SelectItem value="2">Mike Brown (ASP.NET)</SelectItem>
                  <SelectItem value="3">Emily Davis (C#)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="company">Company Name</Label>
              <Input id="company" placeholder="Enter company name" data-testid="input-company" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rate">Hourly Rate</Label>
                <Input id="rate" type="text" placeholder="$85/hr" data-testid="input-rate" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="submissionDate">Submission Date</Label>
                <Input id="submissionDate" type="date" data-testid="input-date" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="jobTitle">Job Title</Label>
              <Input id="jobTitle" placeholder="Senior .NET Developer" data-testid="input-job-title" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea 
                id="notes" 
                placeholder="Add any additional notes about this submission..." 
                rows={4}
                data-testid="textarea-notes"
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={() => setLocation('/sales/submissions')} data-testid="button-submit">
                <Send className="mr-2 h-4 w-4" />
                Submit to Client
              </Button>
              <Button variant="outline" onClick={() => setLocation('/sales/dashboard')} data-testid="button-cancel">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
