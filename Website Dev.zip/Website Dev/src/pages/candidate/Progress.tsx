import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  User, 
  Briefcase, 
  MessageSquare,
  BookOpen,
  CheckCircle2
} from 'lucide-react';

const navItems = [
  { title: 'My Profile', url: '/candidate/dashboard', icon: User },
  { title: 'My Progress', url: '/candidate/progress', icon: Briefcase },
  { title: 'Mock Interviews', url: '/candidate/interviews', icon: MessageSquare },
  { title: 'Resources', url: '/candidate/resources', icon: BookOpen },
];

const progressData = {
  training: { completed: 12, total: 15, percentage: 80 },
  mockInterviews: { completed: 3, total: 5, percentage: 60 },
  skills: [
    { name: '.NET Core', progress: 90 },
    { name: 'C#', progress: 85 },
    { name: 'ASP.NET', progress: 75 },
    { name: 'Entity Framework', progress: 80 },
    { name: 'SQL Server', progress: 70 },
  ]
};

interface MyProgressProps {
  onLogout?: () => void;
}

export default function MyProgress({ onLogout }: MyProgressProps) {
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Alice Williams"
      userRole="Candidate"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Progress</h1>
          <p className="text-muted-foreground mt-1">Track your training and skill development</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Training Modules</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Completion Rate</span>
                  <span className="text-sm text-muted-foreground">
                    {progressData.training.completed}/{progressData.training.total}
                  </span>
                </div>
                <Progress value={progressData.training.percentage} className="h-2" />
              </div>

              <div className="space-y-2 pt-2">
                {[
                  { title: 'Introduction to .NET', completed: true },
                  { title: 'C# Fundamentals', completed: true },
                  { title: 'ASP.NET Core MVC', completed: true },
                  { title: 'Entity Framework Core', completed: false },
                  { title: 'Web API Development', completed: false },
                ].map((module, index) => (
                  <div key={index} className="flex items-center gap-2 p-2 rounded-md border">
                    <CheckCircle2 className={`h-4 w-4 ${module.completed ? 'text-green-600 dark:text-green-400' : 'text-gray-300 dark:text-gray-600'}`} />
                    <span className={`text-sm ${module.completed ? '' : 'text-muted-foreground'}`}>
                      {module.title}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Mock Interviews</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Completion Rate</span>
                  <span className="text-sm text-muted-foreground">
                    {progressData.mockInterviews.completed}/{progressData.mockInterviews.total}
                  </span>
                </div>
                <Progress value={progressData.mockInterviews.percentage} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="text-center p-4 bg-green-500/10 rounded-md border border-green-500/20">
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {progressData.mockInterviews.completed}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Completed</p>
                </div>
                <div className="text-center p-4 border rounded-md">
                  <p className="text-2xl font-bold">
                    {progressData.mockInterviews.total - progressData.mockInterviews.completed}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Remaining</p>
                </div>
              </div>

              <Badge variant="outline" className="w-full justify-center bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20">
                Average Rating: 4.5/5
              </Badge>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Technical Skills Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {progressData.skills.map((skill) => (
              <div key={skill.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{skill.name}</span>
                  <span className="text-sm text-muted-foreground">{skill.progress}%</span>
                </div>
                <Progress value={skill.progress} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
