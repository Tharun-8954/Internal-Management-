import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Star } from 'lucide-react';
import { 
  User, 
  Briefcase, 
  MessageSquare,
  BookOpen
} from 'lucide-react';

const navItems = [
  { title: 'My Profile', url: '/candidate/dashboard', icon: User },
  { title: 'My Progress', url: '/candidate/progress', icon: Briefcase },
  { title: 'Mock Interviews', url: '/candidate/interviews', icon: MessageSquare },
  { title: 'Resources', url: '/candidate/resources', icon: BookOpen },
];

const mockInterviews = [
  { 
    id: 1, 
    date: '2024-12-20', 
    interviewer: 'Jane Smith', 
    rating: 5, 
    feedback: 'Excellent performance, ready for client interviews. Strong technical knowledge and good communication skills.',
    topics: ['C#', 'ASP.NET', 'Design Patterns'],
    status: 'completed' as const
  },
  { 
    id: 2, 
    date: '2024-12-15', 
    interviewer: 'John Doe', 
    rating: 4, 
    feedback: 'Strong technical skills, needs improvement in communication. Good problem-solving abilities.',
    topics: ['.NET Core', 'Entity Framework', 'LINQ'],
    status: 'completed' as const
  },
  { 
    id: 3, 
    date: '2024-12-10', 
    interviewer: 'Mike Johnson', 
    rating: 4, 
    feedback: 'Good understanding of fundamentals. Continue practicing coding challenges.',
    topics: ['C# Basics', 'OOP Concepts', 'SQL'],
    status: 'completed' as const
  },
  { 
    id: 4, 
    date: '2024-12-25', 
    interviewer: 'Sarah Williams', 
    rating: 0, 
    feedback: '',
    topics: ['Advanced .NET', 'Microservices', 'Azure'],
    status: 'scheduled' as const
  },
];

interface InterviewsProps {
  onLogout?: () => void;
}

export default function Interviews({ onLogout }: InterviewsProps) {
  return (
    <DashboardLayout
      navItems={navItems}
      userName="Alice Williams"
      userRole="Candidate"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Mock Interviews</h1>
          <p className="text-muted-foreground mt-1">Review your mock interview history and feedback</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Interviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4</div>
              <p className="text-xs text-muted-foreground mt-1">3 completed, 1 scheduled</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4.3/5</div>
              <div className="flex items-center gap-1 mt-1">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                ))}
                <Star className="h-3 w-3 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Next Interview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Dec 25</div>
              <p className="text-xs text-muted-foreground mt-1">with Sarah Williams</p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Interview History</h2>
          {mockInterviews.map((interview) => (
            <Card key={interview.id} data-testid={`card-interview-${interview.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{interview.date}</span>
                      <Badge 
                        variant="outline" 
                        className={interview.status === 'completed' 
                          ? 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20' 
                          : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20'
                        }
                      >
                        {interview.status === 'completed' ? 'Completed' : 'Scheduled'}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Interviewer: {interview.interviewer}</p>
                  </div>
                  {interview.status === 'completed' && (
                    <div className="flex items-center gap-1">
                      {Array.from({ length: interview.rating }).map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Topics Covered</p>
                  <div className="flex flex-wrap gap-2">
                    {interview.topics.map((topic) => (
                      <Badge key={topic} variant="secondary">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>
                {interview.feedback && (
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Feedback</p>
                    <p className="text-sm">{interview.feedback}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
