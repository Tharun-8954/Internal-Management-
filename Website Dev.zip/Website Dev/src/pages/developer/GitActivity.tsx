import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LayoutDashboard, 
  Code, 
  GitBranch, 
  FileText,
  Terminal,
  Folder,
  GitCommit,
  GitPullRequest,
  GitMerge
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/dev/dashboard', icon: LayoutDashboard },
  { title: 'Projects', url: '/dev/projects', icon: Folder },
  { title: 'Code Reviews', url: '/dev/reviews', icon: Code },
  { title: 'Documentation', url: '/dev/docs', icon: FileText },
  { title: 'Git Activity', url: '/dev/git', icon: GitBranch },
];

const recentActivity = [
  { id: 1, type: 'commit' as const, message: 'feat: Add user authentication', project: 'Internal CRM', time: '2 hours ago', author: 'David Chen' },
  { id: 2, type: 'merge' as const, message: 'Merged feature/payment-gateway', project: 'API Gateway', time: '5 hours ago', author: 'David Chen' },
  { id: 3, type: 'pr' as const, message: 'Created PR: Update database schema', project: 'Internal CRM', time: '1 day ago', author: 'David Chen' },
  { id: 4, type: 'commit' as const, message: 'fix: Resolve API endpoint issue', project: 'Analytics Dashboard', time: '1 day ago', author: 'David Chen' },
  { id: 5, type: 'merge' as const, message: 'Merged hotfix/security-patch', project: 'API Gateway', time: '2 days ago', author: 'David Chen' },
];

interface GitActivityProps {
  onLogout?: () => void;
}

export default function GitActivity({ onLogout }: GitActivityProps) {
  const getIcon = (type: 'commit' | 'merge' | 'pr') => {
    switch (type) {
      case 'commit':
        return <GitCommit className="h-4 w-4" />;
      case 'merge':
        return <GitMerge className="h-4 w-4" />;
      case 'pr':
        return <GitPullRequest className="h-4 w-4" />;
    }
  };

  const getColor = (type: 'commit' | 'merge' | 'pr') => {
    switch (type) {
      case 'commit':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
      case 'merge':
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
      case 'pr':
        return 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20';
    }
  };

  return (
    <DashboardLayout
      navItems={navItems}
      userName="David Chen"
      userRole="Developer"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Git Activity</h1>
          <p className="text-muted-foreground mt-1">
            Track your git commits, merges, and pull requests
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Commits</CardTitle>
              <GitCommit className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">147</div>
              <p className="text-xs text-muted-foreground mt-1">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pull Requests</CardTitle>
              <GitPullRequest className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">23</div>
              <p className="text-xs text-muted-foreground mt-1">8 open, 15 closed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Merges</CardTitle>
              <GitMerge className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">18</div>
              <p className="text-xs text-muted-foreground mt-1">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Branches</CardTitle>
              <GitBranch className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground mt-1">Across all projects</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-3 border rounded-md" data-testid={`activity-${activity.id}`}>
                  <div className={`p-2 rounded-md ${getColor(activity.type)}`}>
                    {getIcon(activity.type)}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{activity.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="text-xs">{activity.project}</Badge>
                      <span className="text-xs text-muted-foreground">•</span>
                      <div className="flex items-center gap-1">
                        <Avatar className="h-4 w-4">
                          <AvatarImage src="" alt={activity.author} />
                          <AvatarFallback className="text-xs">DC</AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground">{activity.author}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">{activity.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
