import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LayoutDashboard, 
  Code, 
  GitBranch, 
  FileText,
  Terminal,
  Folder,
  MessageSquare
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/dev/dashboard', icon: LayoutDashboard },
  { title: 'Projects', url: '/dev/projects', icon: Folder },
  { title: 'Code Reviews', url: '/dev/reviews', icon: Code },
  { title: 'Documentation', url: '/dev/docs', icon: FileText },
  { title: 'Git Activity', url: '/dev/git', icon: GitBranch },
];

const pendingReviews = [
  { id: 1, title: 'Add user authentication module', author: 'Sarah Williams', project: 'Internal CRM', comments: 3, status: 'pending' as const },
  { id: 2, title: 'Refactor API endpoints', author: 'Mike Johnson', project: 'API Gateway', comments: 5, status: 'pending' as const },
];

const completedReviews = [
  { id: 3, title: 'Update database schema', author: 'Tom Davis', project: 'Internal CRM', comments: 2, status: 'approved' as const },
  { id: 4, title: 'Fix security vulnerabilities', author: 'Emma Watson', project: 'Analytics Dashboard', comments: 4, status: 'approved' as const },
];

interface CodeReviewsProps {
  onLogout?: () => void;
}

export default function CodeReviews({ onLogout }: CodeReviewsProps) {
  return (
    <DashboardLayout
      navItems={navItems}
      userName="David Chen"
      userRole="Developer"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Code Reviews</h1>
          <p className="text-muted-foreground mt-1">
            Review pull requests and provide feedback
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pendingReviews.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Requires attention</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8</div>
              <p className="text-xs text-muted-foreground mt-1">Reviews completed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2.5h</div>
              <p className="text-xs text-muted-foreground mt-1">Last 7 days</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Pending Reviews</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingReviews.map((review) => (
              <div key={review.id} className="p-4 border rounded-md space-y-3 hover-elevate" data-testid={`review-${review.id}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">{review.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{review.project}</p>
                  </div>
                  <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">
                    Pending
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src="" alt={review.author} />
                      <AvatarFallback className="text-xs">{review.author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-muted-foreground">{review.author}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <MessageSquare className="h-3 w-3" />
                      {review.comments}
                    </span>
                    <Button size="sm">Review</Button>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Completed</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {completedReviews.map((review) => (
              <div key={review.id} className="p-4 border rounded-md space-y-3" data-testid={`review-${review.id}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">{review.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{review.project}</p>
                  </div>
                  <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
                    Approved
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src="" alt={review.author} />
                      <AvatarFallback className="text-xs">{review.author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-muted-foreground">{review.author}</span>
                  </div>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <MessageSquare className="h-3 w-3" />
                    {review.comments}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
