import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import StatCard from '@/components/StatCard';
import CandidateCard from '@/components/CandidateCard';
import SubmissionTable from '@/components/SubmissionTable';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  Users, 
  FileText,
  CheckCircle,
  Send 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/sales/dashboard', icon: LayoutDashboard },
  { title: 'My Candidates', url: '/sales/candidates', icon: Users },
  { title: 'Submissions', url: '/sales/submissions', icon: FileText },
];

const mockCandidates = [
  { id: '1', name: 'John Smith', technology: '.NET Core', batch: 'Net' as const, phase: 'marketing' as const, experience: 3, progress: 85 },
  { id: '2', name: 'Mike Brown', technology: 'ASP.NET', batch: 'Net' as const, phase: 'mock_interviews' as const, experience: 4, progress: 75 },
  { id: '3', name: 'Emily Davis', technology: 'C#', batch: 'Net' as const, phase: 'training' as const, experience: 2, progress: 50 },
];

const mockSubmissions = [
  { id: '1', candidateName: 'John Smith', company: 'Tech Corp', submissionDate: '2024-01-15', rate: '$85/hr', status: 'interview' as const },
  { id: '2', candidateName: 'Mike Brown', company: 'Innovation Labs', submissionDate: '2024-01-14', rate: '$80/hr', status: 'assessment' as const },
];

interface SalesEmployeeDashboardProps {
  onLogout?: () => void;
}

export default function SalesEmployeeDashboard({ onLogout }: SalesEmployeeDashboardProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Bob Johnson"
      userRole="Sales Employee"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">My Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Manage your assigned candidates and submissions
            </p>
          </div>
          <Button onClick={() => setLocation('/sales/submissions/new')} data-testid="button-new-submission">
            <Send className="mr-2 h-4 w-4" />
            New Submission
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard
            title="Assigned Candidates"
            value={8}
            icon={Users}
            description="Active assignments"
          />
          <StatCard
            title="Submissions"
            value={12}
            icon={Send}
            description="This month"
          />
          <StatCard
            title="Placements"
            value={3}
            icon={CheckCircle}
            description="This quarter"
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">My Candidates</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockCandidates.map(candidate => (
              <CandidateCard
                key={candidate.id}
                {...candidate}
                onClick={() => setLocation(`/sales/candidates/${candidate.id}`)}
              />
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Recent Submissions</h2>
          <SubmissionTable
            submissions={mockSubmissions}
            onViewDetails={(id) => setLocation(`/sales/submissions/${id}`)}
          />
        </div>
      </div>
    </DashboardLayout>
  );
}
