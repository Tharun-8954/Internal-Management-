import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import UserTable from '@/components/UserTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  UserCheck,
  Search 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Reports', url: '/admin/reports', icon: FileText },
];

const mockUsers = [
  { id: '1', name: 'John Doe', email: 'john@saggisolutions.com', role: 'admin', status: 'active' as const },
  { id: '2', name: 'Jane Smith', email: 'jane@saggisolutions.com', role: 'sales_manager', status: 'active' as const },
  { id: '3', name: 'Bob Johnson', email: 'bob@saggisolutions.com', role: 'sales_employee', status: 'active' as const },
  { id: '4', name: 'Alice Williams', email: 'alice@saggisolutions.com', role: 'candidate', status: 'active' as const },
  { id: '5', name: 'David Chen', email: 'david@saggisolutions.com', role: 'developer', status: 'active' as const },
  { id: '6', name: 'Emma Watson', email: 'emma@saggisolutions.com', role: 'candidate', status: 'active' as const },
  { id: '7', name: 'Michael Scott', email: 'michael@saggisolutions.com', role: 'sales_employee', status: 'inactive' as const },
];

interface UsersManagementProps {
  onLogout?: () => void;
}

export default function UsersManagement({ onLogout }: UsersManagementProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Users Management</h1>
            <p className="text-muted-foreground mt-1">
              Manage all system users and their roles
            </p>
          </div>
          <Button onClick={() => setLocation('/admin/users?action=new')} data-testid="button-add-user">
            <UserPlus className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search users..."
              className="pl-10"
              data-testid="input-search-users"
            />
          </div>
        </div>

        <UserTable
          users={mockUsers}
          onEdit={(userId) => setLocation(`/admin/users/${userId}`)}
          onDelete={(userId) => setLocation(`/admin/users/${userId}?action=delete`)}
        />
      </div>
    </DashboardLayout>
  );
}
