import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import CandidateCard from '@/components/CandidateCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  FileText,
  UserCheck,
  Search,
  UserPlus
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Reports', url: '/admin/reports', icon: FileText },
];

const mockCandidates = [
  { id: '1', name: 'John Smith', technology: '.NET Core', batch: 'Net' as const, phase: 'training' as const, experience: 3, progress: 65 },
  { id: '2', name: 'Sarah Johnson', technology: 'Dynamics 365', batch: 'Dynamics' as const, phase: 'marketing' as const, experience: 5, progress: 90 },
  { id: '3', name: 'Mike Brown', technology: 'ASP.NET', batch: 'Net' as const, phase: 'mock_interviews' as const, experience: 4, progress: 75 },
  { id: '4', name: 'Emily Davis', technology: 'C#', batch: 'Net' as const, phase: 'training' as const, experience: 2, progress: 50 },
  { id: '5', name: 'James Wilson', technology: 'Dynamics CRM', batch: 'Dynamics' as const, phase: 'placed' as const, experience: 6, progress: 100 },
];

interface AllCandidatesProps {
  onLogout?: () => void;
}

export default function AllCandidates({ onLogout }: AllCandidatesProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">All Candidates</h1>
            <p className="text-muted-foreground mt-1">
              View and manage all candidates across batches
            </p>
          </div>
          <Button onClick={() => setLocation('/admin/candidates?action=new')} data-testid="button-add-candidate">
            <UserPlus className="mr-2 h-4 w-4" />
            Add Candidate
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search candidates..."
              className="pl-10"
              data-testid="input-search-candidates"
            />
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all" data-testid="tab-all">All Candidates</TabsTrigger>
            <TabsTrigger value="net" data-testid="tab-net">Net Batch</TabsTrigger>
            <TabsTrigger value="dynamics" data-testid="tab-dynamics">Dynamics Batch</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockCandidates.map(candidate => (
                <CandidateCard
                  key={candidate.id}
                  {...candidate}
                  onClick={() => setLocation(`/admin/candidates?id=${candidate.id}`)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="net" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockCandidates.filter(c => c.batch === 'Net').map(candidate => (
                <CandidateCard
                  key={candidate.id}
                  {...candidate}
                  onClick={() => setLocation(`/admin/candidates?id=${candidate.id}`)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="dynamics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockCandidates.filter(c => c.batch === 'Dynamics').map(candidate => (
                <CandidateCard
                  key={candidate.id}
                  {...candidate}
                  onClick={() => setLocation(`/admin/candidates?id=${candidate.id}`)}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
