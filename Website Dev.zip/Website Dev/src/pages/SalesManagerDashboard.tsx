import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import StatCard from '@/components/StatCard';
import CandidateCard from '@/components/CandidateCard';
import SubmissionTable from '@/components/SubmissionTable';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  Target,
  TrendingUp 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/manager/dashboard', icon: LayoutDashboard },
  { title: 'My Team', url: '/manager/team', icon: Users },
  { title: 'Batches', url: '/manager/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/manager/candidates', icon: UserPlus },
  { title: 'Submissions', url: '/manager/submissions', icon: FileText },
  { title: 'Assignments', url: '/manager/assignments', icon: Target },
];

const mockCandidates = [
  { id: '1', name: 'John Smith', technology: '.NET Core', batch: 'Net' as const, phase: 'training' as const, experience: 3, progress: 65 },
  { id: '2', name: 'Sarah Johnson', technology: 'Dynamics 365', batch: 'Dynamics' as const, phase: 'marketing' as const, experience: 5, progress: 90 },
  { id: '3', name: 'Mike Brown', technology: 'ASP.NET', batch: 'Net' as const, phase: 'mock_interviews' as const, experience: 4, progress: 75 },
];

const mockSubmissions = [
  { id: '1', candidateName: 'John Smith', company: 'Tech Corp', submissionDate: '2024-01-15', rate: '$85/hr', status: 'interview' as const },
  { id: '2', candidateName: 'Sarah Johnson', company: 'Global Industries', submissionDate: '2024-01-14', rate: '$90/hr', status: 'offer' as const },
];

interface SalesManagerDashboardProps {
  onLogout?: () => void;
}

export default function SalesManagerDashboard({ onLogout }: SalesManagerDashboardProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Jane Smith"
      userRole="Sales Manager"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Sales Manager Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Manage your team and track candidate progress
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Sales Employees"
            value={5}
            icon={Users}
            description="Active team members"
          />
          <StatCard
            title="Active Assignments"
            value={28}
            icon={Target}
            description="Across all employees"
          />
          <StatCard
            title="This Month Placed"
            value={4}
            icon={TrendingUp}
            description="+2 from last month"
          />
          <StatCard
            title="Submissions"
            value={15}
            icon={FileText}
            description="This month"
          />
        </div>

        <Tabs defaultValue="candidates" className="space-y-4">
          <TabsList>
            <TabsTrigger value="candidates" data-testid="tab-candidates">Candidates</TabsTrigger>
            <TabsTrigger value="submissions" data-testid="tab-submissions">Recent Submissions</TabsTrigger>
            <TabsTrigger value="team" data-testid="tab-team">Team Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="candidates" className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Candidate Pipeline</h2>
              <Button onClick={() => setLocation('/manager/assignments')} data-testid="button-assign-candidates">
                <Target className="mr-2 h-4 w-4" />
                Assign Candidates
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockCandidates.map(candidate => (
                <CandidateCard
                  key={candidate.id}
                  {...candidate}
                  onClick={() => setLocation(`/manager/candidates/${candidate.id}`)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="submissions" className="space-y-4">
            <SubmissionTable
              submissions={mockSubmissions}
              onViewDetails={(id) => setLocation(`/manager/submissions/${id}`)}
            />
          </TabsContent>

          <TabsContent value="team" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Candidates by Phase</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Training</span>
                    <span className="text-sm font-semibold">12</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Mock Interviews</span>
                    <span className="text-sm font-semibold">8</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Marketing</span>
                    <span className="text-sm font-semibold">8</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Placed</span>
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">4</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
