import { useLocation } from 'wouter';
import DashboardLayout from '@/components/DashboardLayout';
import StatCard from '@/components/StatCard';
import UserTable from '@/components/UserTable';
import BatchCard from '@/components/BatchCard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  UserPlus, 
  FileText,
  TrendingUp,
  UserCheck,
  Briefcase 
} from 'lucide-react';

const navItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Users Management', url: '/admin/users', icon: Users },
  { title: 'Batches', url: '/admin/batches', icon: GraduationCap },
  { title: 'All Candidates', url: '/admin/candidates', icon: UserCheck },
  { title: 'Reports', url: '/admin/reports', icon: FileText },
];

const mockUsers = [
  { id: '1', name: 'John Doe', email: 'john@saggisolutions.com', role: 'admin', status: 'active' as const },
  { id: '2', name: 'Jane Smith', email: 'jane@saggisolutions.com', role: 'sales_manager', status: 'active' as const },
  { id: '3', name: 'Bob Johnson', email: 'bob@saggisolutions.com', role: 'sales_employee', status: 'active' as const },
  { id: '4', name: 'Alice Williams', email: 'alice@saggisolutions.com', role: 'candidate', status: 'active' as const },
  { id: '5', name: 'David Chen', email: 'david@saggisolutions.com', role: 'developer', status: 'active' as const },
];

interface AdminDashboardProps {
  onLogout?: () => void;
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout
      navItems={navItems}
      userName="Admin User"
      userRole="Administrator"
      onLogout={onLogout}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Manage users, batches, and monitor system performance
            </p>
          </div>
          <Button onClick={() => setLocation('/admin/users?action=new')} data-testid="button-add-user">
            <UserPlus className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total Users"
            value={127}
            icon={Users}
            description="+12 from last month"
          />
          <StatCard
            title="Active Candidates"
            value={45}
            icon={UserCheck}
            description="Across both batches"
          />
          <StatCard
            title="Placed This Month"
            value={8}
            icon={TrendingUp}
            description="+25% from last month"
          />
          <StatCard
            title="Sales Team"
            value={12}
            icon={Briefcase}
            description="5 managers, 7 employees"
          />
        </div>

        <Tabs defaultValue="batches" className="space-y-4">
          <TabsList>
            <TabsTrigger value="batches" data-testid="tab-batches">Batches</TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="batches" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <BatchCard
                id="1"
                name="Net"
                description="Microsoft .NET Technologies"
                totalCandidates={28}
                trainingCount={12}
                mockInterviewCount={8}
                marketingCount={6}
                placedCount={2}
                isActive={true}
                onViewDetails={() => setLocation('/admin/batches/1')}
              />
              <BatchCard
                id="2"
                name="Dynamics"
                description="Microsoft Dynamics 365"
                totalCandidates={17}
                trainingCount={5}
                mockInterviewCount={7}
                marketingCount={3}
                placedCount={2}
                isActive={true}
                onViewDetails={() => setLocation('/admin/batches/2')}
              />
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <UserTable
              users={mockUsers}
              onEdit={(userId) => setLocation(`/admin/users/${userId}`)}
              onDelete={(userId) => setLocation(`/admin/users/${userId}?action=delete`)}
            />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
