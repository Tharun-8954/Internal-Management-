import StatCard from '../StatCard';
import { Users } from 'lucide-react';

export default function StatCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
      <StatCard title="Total Users" value={127} icon={Users} description="+12 from last month" />
      <StatCard title="Active Candidates" value={45} icon={Users} />
    </div>
  );
}
