import UserTable from '../UserTable';

const mockUsers = [
  { id: '1', name: 'John Doe', email: 'john@saggisolutions.com', role: 'admin', status: 'active' as const },
  { id: '2', name: 'Jane Smith', email: 'jane@saggisolutions.com', role: 'sales_manager', status: 'active' as const },
  { id: '3', name: 'Bob Johnson', email: 'bob@saggisolutions.com', role: 'sales_employee', status: 'inactive' as const },
];

export default function UserTableExample() {
  return (
    <div className="p-6">
      <UserTable
        users={mockUsers}
        onEdit={(id) => console.log('Edit user:', id)}
        onDelete={(id) => console.log('Delete user:', id)}
      />
    </div>
  );
}
