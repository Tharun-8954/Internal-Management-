import DashboardLayout from '../DashboardLayout';
import { LayoutDashboard, Users, GraduationCap } from 'lucide-react';

export default function DashboardLayoutExample() {
  const navItems = [
    { title: 'Dashboard', url: '/', icon: LayoutDashboard },
    { title: 'Users', url: '/users', icon: Users },
    { title: 'Batches', url: '/batches', icon: GraduationCap },
  ];

  return (
    <DashboardLayout
      navItems={navItems}
      userName="John Doe"
      userRole="Admin"
      onLogout={() => {}}
    >
      <div className="p-6">
        <h1 className="text-2xl font-bold">Dashboard Content</h1>
        <p className="text-muted-foreground mt-2">This is the main content area.</p>
      </div>
    </DashboardLayout>
  );
}
