import SalesEmployeeDashboard from '../../pages/SalesEmployeeDashboard';

export default function SalesEmployeeDashboardExample() {
  return <SalesEmployeeDashboard />;
}
