import CandidateCard from '../CandidateCard';

export default function CandidateCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
      <CandidateCard
        id="1"
        name="John Smith"
        technology=".NET"
        batch="Net"
        phase="training"
        experience={3}
        progress={65}
        onClick={() => console.log('Candidate clicked')}
      />
      <CandidateCard
        id="2"
        name="Sarah Johnson"
        technology="Dynamics 365"
        batch="Dynamics"
        phase="marketing"
        experience={5}
        progress={90}
        onClick={() => console.log('Candidate clicked')}
      />
    </div>
  );
}
