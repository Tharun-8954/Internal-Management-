import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, TrendingUp } from 'lucide-react';

interface BatchCardProps {
  id: string;
  name: 'Net' | 'Dynamics';
  description: string;
  totalCandidates: number;
  trainingCount: number;
  mockInterviewCount: number;
  marketingCount: number;
  placedCount: number;
  isActive: boolean;
  onViewDetails?: () => void;
}

export default function BatchCard({
  id,
  name,
  description,
  totalCandidates,
  trainingCount,
  mockInterviewCount,
  marketingCount,
  placedCount,
  isActive,
  onViewDetails,
}: BatchCardProps) {
  return (
    <Card data-testid={`card-batch-${id}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-xl">{name} Batch</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          </div>
          <Badge variant={isActive ? "default" : "secondary"}>
            {isActive ? 'Active' : 'Inactive'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">{totalCandidates} Total Candidates</span>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Training</p>
            <p className="text-lg font-semibold">{trainingCount}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Mock Interviews</p>
            <p className="text-lg font-semibold">{mockInterviewCount}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Marketing</p>
            <p className="text-lg font-semibold">{marketingCount}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Placed</p>
            <p className="text-lg font-semibold text-green-600 dark:text-green-400 flex items-center gap-1">
              {placedCount}
              <TrendingUp className="h-3 w-3" />
            </p>
          </div>
        </div>

        <Button 
          onClick={onViewDetails} 
          className="w-full" 
          variant="outline"
          data-testid={`button-view-batch-${id}`}
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}
