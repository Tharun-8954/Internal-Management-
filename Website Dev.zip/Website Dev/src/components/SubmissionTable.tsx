import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye } from 'lucide-react';

interface Submission {
  id: string;
  candidateName: string;
  company: string;
  submissionDate: string;
  rate: string;
  status: 'submitted' | 'initial_screening' | 'assessment' | 'interview' | 'offer' | 'placed' | 'rejected';
}

interface SubmissionTableProps {
  submissions: Submission[];
  onViewDetails?: (submissionId: string) => void;
}

const statusColors: Record<Submission['status'], string> = {
  submitted: 'bg-gray-500/10 text-gray-700 dark:text-gray-400 border-gray-500/20',
  initial_screening: 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20',
  assessment: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20',
  interview: 'bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/20',
  offer: 'bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/20',
  placed: 'bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20',
  rejected: 'bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20',
};

export default function SubmissionTable({ submissions, onViewDetails }: SubmissionTableProps) {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Candidate</TableHead>
            <TableHead>Company</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Rate</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="w-[80px]">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {submissions.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                No submissions found
              </TableCell>
            </TableRow>
          ) : (
            submissions.map((submission) => (
              <TableRow key={submission.id} data-testid={`row-submission-${submission.id}`}>
                <TableCell className="font-medium">{submission.candidateName}</TableCell>
                <TableCell>{submission.company}</TableCell>
                <TableCell className="text-muted-foreground">{submission.submissionDate}</TableCell>
                <TableCell className="font-semibold text-primary">{submission.rate}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={`capitalize ${statusColors[submission.status]}`}>
                    {submission.status.replace('_', ' ')}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onViewDetails?.(submission.id)}
                    data-testid={`button-view-${submission.id}`}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
