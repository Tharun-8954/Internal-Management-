import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";

interface CandidateCardProps {
  id: string;
  name: string;
  technology: string;
  batch: 'Net' | 'Dynamics';
  phase: 'training' | 'mock_interviews' | 'marketing' | 'placed';
  experience: number;
  avatar?: string;
  progress?: number;
  onClick?: () => void;
}

const phaseColors = {
  training: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
  mock_interviews: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20',
  marketing: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20',
  placed: 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20',
};

const phaseLabels = {
  training: 'Training',
  mock_interviews: 'Mock Interviews',
  marketing: 'Marketing',
  placed: 'Placed',
};

const batchColors = {
  Net: 'bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border-cyan-500/20',
  Dynamics: 'bg-indigo-500/10 text-indigo-700 dark:text-indigo-400 border-indigo-500/20',
};

export default function CandidateCard({ 
  id, 
  name, 
  technology, 
  batch, 
  phase, 
  experience, 
  avatar, 
  progress = 0,
  onClick 
}: CandidateCardProps) {
  const initials = name.split(' ').map(n => n[0]).join('').toUpperCase();
  
  return (
    <Card 
      className="hover-elevate cursor-pointer" 
      onClick={onClick}
      data-testid={`card-candidate-${id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src={avatar} alt={name} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm truncate">{name}</h3>
                <p className="text-xs text-muted-foreground">{technology} • {experience} years</p>
              </div>
              <Badge variant="outline" className={`shrink-0 text-xs ${batchColors[batch]}`}>
                {batch}
              </Badge>
            </div>
            
            <div className="mt-3 space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className={`text-xs ${phaseColors[phase]}`}>
                  {phaseLabels[phase]}
                </Badge>
                <span className="text-xs text-muted-foreground ml-auto">{progress}%</span>
              </div>
              <Progress value={progress} className="h-1.5" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
